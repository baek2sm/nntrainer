"""Numerical and artifact contracts using an offline, randomly initialized Qwen3."""

import json
import shutil
from argparse import Namespace
from pathlib import Path

import numpy as np
import pytest

from benchmarks.sparse_bench.cases import (
    align,
    make_manifest,
    read_manifest,
    render,
    tokenize,
)
from benchmarks.sparse_bench.metrics import (
    distributions,
    judge,
    kv_stats,
    relative,
    summarize,
)


@pytest.fixture
def spec():
    return {
        "name": "test",
        "header": "Tools:\n",
        "footer": "\nEnd tools.\n",
        "tools": [
            {"id": "alpha", "text": "alpha: rain forecast\n"},
            {"id": "beta", "text": "beta: music player\n"},
            {"id": "gamma", "text": "gamma: alarm clock\n"},
        ],
        "query_format": "User: {query}\nTool:",
        "no_tool": "no_tool",
        "queries": [
            {"id": "weather", "target": "alpha", "text": "Rain today?", "family": "a"},
            {"id": "music", "target": "beta", "text": "Play music", "family": "b"},
        ],
    }


@pytest.fixture
def backend(spec):
    torch = pytest.importorskip("torch")
    transformers = pytest.importorskip("transformers")
    from tokenizers import Tokenizer, decoders, models, pre_tokenizers, trainers

    from benchmarks.sparse_bench.backend import QwenBackend

    torch.manual_seed(7)
    torch.set_num_threads(1)
    raw = Tokenizer(models.BPE(unk_token="[UNK]"))
    raw.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=False)
    raw.decoder = decoders.ByteLevel()
    corpus = [
        render(spec, list(range(3)))[0],
        spec["query_format"].format(query="Rain today? Play music"),
    ]
    raw.train_from_iterator(
        corpus, trainers.BpeTrainer(vocab_size=100, special_tokens=["[UNK]", "[EOS]"])
    )
    tokenizer = transformers.PreTrainedTokenizerFast(
        tokenizer_object=raw, eos_token="[EOS]", unk_token="[UNK]"
    )
    config = transformers.Qwen3Config(
        vocab_size=len(tokenizer),
        hidden_size=32,
        intermediate_size=64,
        num_hidden_layers=3,
        num_attention_heads=4,
        num_key_value_heads=2,
        head_dim=8,
        max_position_embeddings=512,
        eos_token_id=tokenizer.eos_token_id,
        attention_dropout=0.0,
    )
    config._attn_implementation = "eager"
    return QwenBackend(transformers.Qwen3ForCausalLM(config), tokenizer)


def test_exhaustive_masks_and_checksum(spec, tmp_path):
    manifest = make_manifest(spec, 3)
    assert len(manifest["masks"]) == 8
    assert {tuple(m["kept"]) for m in manifest["masks"]} == {
        (),
        (0,),
        (1,),
        (2,),
        (0, 1),
        (0, 2),
        (1, 2),
        (0, 1, 2),
    }
    path = tmp_path / "manifest.json"
    path.write_text(json.dumps(manifest))
    assert read_manifest(path) == manifest == make_manifest(spec, 3)
    manifest["masks"][0]["kept"] = [0]
    path.write_text(json.dumps(manifest))
    with pytest.raises(ValueError, match="checksum"):
        read_manifest(path)


def test_default_workload_counts():
    from benchmarks.sparse_bench import cases

    spec = json.loads(Path(cases.__file__).with_name("device_tools.json").read_text())
    manifest = make_manifest(spec)
    assert len(manifest["masks"]) == 1024
    assert len(spec["queries"]) == 30
    assert sum(len(m["kept"]) for m in manifest["masks"]) == 5120
    assert spec["prompt_format"] == "chat"


def test_duplicate_unicode_offsets_match_occurrences():
    # Some byte-level tokenizers produce several tokens with one character span.
    tokens = [
        {"position": i, "block": "tool", "local_start": 0, "local_end": 1, "id": 7}
        for i in range(3)
    ]
    assert align(tokens, tokens) == [0, 1, 2]


def test_alignment_never_reuses_mismatched_ids_or_cross_boundary(spec, backend):
    full, spans = render(spec, [0, 1, 2])
    source = tokenize(backend.tokenizer, full, spans)
    text, spans = render(spec, [0, 2])
    target = tokenize(backend.tokenizer, text, spans)
    mapping = align(source, target)
    assert any(i >= 0 for i in mapping)
    for token, position in zip(target, mapping, strict=False):
        if position >= 0:
            assert token["id"] == source[position]["id"]
            assert token["block"] == source[position]["block"] != "boundary"
    bad = [dict(target[0], id=999999)]
    assert align(source, bad) == [-1]
    assert align(source, [dict(target[0], block="boundary")]) == [-1]


def test_energy_aggregation_and_zero_reference():
    ref = np.ones((2, 2, 3, 2, 4))
    ref[:, :, 1] *= 100
    arm = ref.copy()
    arm[:, :, 0] += 1
    stats = kv_stats(arm, ref)
    overall = summarize(stats)
    assert overall["k"]["relative_l2"] == pytest.approx(
        np.linalg.norm(arm[:, 0] - ref[:, 0]) / np.linalg.norm(ref[:, 0])
    )
    assert sum(stats["head_error_sq"].flatten()) == pytest.approx(
        stats["error_sq"].sum()
    )
    assert relative(0, 0) is None
    with pytest.raises(ValueError, match="non-finite"):
        kv_stats(arm * np.nan, ref)


def test_layer_error_energy_uses_sums_and_excludes_boundary_masks(tmp_path):
    import csv

    from benchmarks.sparse_bench.report import layer_error_energy

    cases = {}
    for mask, kept, energies, tokens in (
        ("a", [0], [1, 2], 3),
        ("b", [1], [3, 4], 5),
        ("empty", [], [100, 100], 2),
        ("full", [0, 1], [100, 100], 6),
    ):
        cases[mask] = {"mask": {"kept": kept}}
        path = tmp_path / "cases" / mask / "rope"
        path.mkdir(parents=True)
        error = np.zeros((2, 2, tokens))
        error[:, 0, 0] = energies
        np.savez(path / "stats.npz", error_sq=error)
    info = layer_error_energy(tmp_path, tmp_path, cases, 2)
    assert info["partial_masks"] == 2
    with (tmp_path / info["file"]).open() as stream:
        rows = list(csv.DictReader(stream))
    assert [float(r["k_error_sq"]) for r in rows] == [4, 6]
    assert float(rows[0]["k_error_energy_fraction"]) == pytest.approx(0.4)
    assert float(rows[-1]["k_cumulative_error_energy_fraction"]) == pytest.approx(1)
    assert all(r["v_error_energy_fraction"] == "" for r in rows)


def test_strict_quality_and_full_vocabulary():
    assert judge(" alpha\n", "alpha", {"alpha", "beta"})["correct"]
    assert not judge("alpha or beta", "alpha", {"alpha", "beta"})["correct"]
    assert not judge("alpha", "alpha", {"beta"})["format_valid"]
    result = distributions([[0, 0]], [[np.log(3), 0]])
    assert result["tvd"][0] == pytest.approx(0.25)
    assert result["kl_cold_to_arm"][0] > 0


def test_token_preservation_tracks_drift_and_horizon_eligibility():
    from benchmarks.sparse_bench.metrics import token_preservation

    result = token_preservation([1, 2, 3, 4], [1, 2, 9, 4])
    assert result["common_prefix_tokens"] == 2
    assert result["position_match_fraction"] == 0.75
    assert result["common_prefix_fraction"] == 0.5
    assert result["first_divergence"] == 2
    assert result["prefix_survival"]["4"] is False
    assert result["prefix_survival"]["64"] is None
    short = token_preservation([1, 2, 3, 4], [1, 2])
    assert short["position_match_fraction"] == 0.5
    exact = token_preservation(list(range(96)), list(range(96)))
    assert exact["first_divergence"] is None
    assert exact["prefix_survival"]["96"] is True
    assert judge("alpha\nA longer explanation.", "alpha", {"alpha"}, "tool_first_line")[
        "correct"
    ]
    truncated = judge(
        '```json\n{"tool":"alpha","reason":"unfinished', "alpha", {"alpha"}, "tool_json"
    )
    assert truncated["correct"] and not truncated["format_valid"]
    assert not judge('{"tool":["alpha"]}', "alpha", {"alpha"}, "tool_json")["correct"]
    assert not judge('{"tool":"\\q"}', "alpha", {"alpha"}, "tool_json")["correct"]


def test_real_recompute_full_and_sparse_causality(spec, backend):
    text, spans = render(spec, [0, 1, 2])
    source_tokens = tokenize(backend.tokenizer, text, spans)
    source = backend.prefill([t["id"] for t in source_tokens])
    text, spans = render(spec, [0, 2])
    tokens = tokenize(backend.tokenizer, text, spans)
    ids = [t["id"] for t in tokens]
    mapping = align(source_tokens, tokens)
    base = backend.splice(source, mapping, True)
    gt = backend.prefill(ids)
    recomputed, positions = backend.recompute(base, ids, list(range(len(ids))))
    np.testing.assert_allclose(
        backend.array(recomputed), backend.array(gt), atol=1e-6, rtol=1e-5
    )
    # Last token cannot change any earlier cache entries.
    edited, _ = backend.recompute(base, ids, [len(ids) - 1])
    np.testing.assert_array_equal(
        backend.array(edited)[:, :, :-1], backend.array(base)[:, :, :-1]
    )
    # Early-key all-token budget reaches the same full recompute path.
    edited, _ = backend.recompute(base, ids, [], 1, list(range(len(ids))), len(ids))
    np.testing.assert_allclose(
        backend.array(edited), backend.array(gt), atol=1e-6, rtol=1e-5
    )
    assert positions == list(range(len(ids)))


def test_cacheblend_storage_ablation_uses_same_budget(spec, backend):
    import math

    from benchmarks.sparse_bench.runner import construct

    text, spans = render(spec, [0, 1, 2])
    tokens = tokenize(backend.tokenizer, text, spans)
    ids = [t["id"] for t in tokens]
    cuts = [0, len(ids) // 2, len(ids)]
    source = backend.prefill(ids)
    independent = backend.independent_prefill(ids, cuts)
    # The second fragment lacks the first fragment's context.
    assert not np.allclose(backend.array(source), backend.array(independent))
    mapping = list(range(len(ids)))
    candidates = mapping.copy()
    for method in ("cacheblend_independent", "cacheblend_superset"):
        edited, selected = construct(
            backend,
            source,
            mapping,
            ids,
            [],
            candidates,
            None,
            0,
            1,
            method,
            0.15,
            independent,
        )
        assert len(selected) == math.ceil(0.15 * len(ids))
        full, selected = construct(
            backend,
            source,
            mapping,
            ids,
            [],
            candidates,
            None,
            0,
            1,
            method,
            1,
            independent,
        )
        np.testing.assert_allclose(
            backend.array(full), backend.array(source), atol=1e-6, rtol=1e-5
        )


def test_gap_uses_removed_tools_not_tokenization_seams():
    from benchmarks.sparse_bench.backend import select_positions

    mapping = [0, 1, 10, 11, 12, 13, -1, 17, 18]
    chosen = select_positions("gap", None, None, mapping, 4, 0, [2])
    assert chosen == [2, 3, 4, 5]
    with pytest.raises(ValueError, match="anchors"):
        select_positions("gap", None, None, mapping, 4, 0)


def test_fixed_gap_windows_merge_clip_and_handle_no_deletion():
    from benchmarks.sparse_bench.backend import select_gap_chunks

    assert select_gap_chunks(100, [10, 20, 90], 16) == list(range(10, 36)) + list(
        range(90, 100)
    )
    assert select_gap_chunks(100, [], 16) == []
    with pytest.raises(ValueError):
        select_gap_chunks(100, [100], 16)


def test_leading_layer_refresh_skips_reads_and_preserves_later_valid_kv(spec, backend):
    from benchmarks.sparse_bench.runner import construct

    text, spans = render(spec, [0, 1, 2])
    source_tokens = tokenize(backend.tokenizer, text, spans)
    source = backend.prefill([t["id"] for t in source_tokens])
    text, spans = render(spec, [0, 2])
    tokens = tokenize(backend.tokenizer, text, spans)
    ids = [t["id"] for t in tokens]
    mapping = align(source_tokens, tokens)
    mandatory = [i for i, src in enumerate(mapping) if src < 0]
    candidates = [i for i, src in enumerate(mapping) if src >= 0]
    cold = backend.array(backend.prefill(ids))
    rope = backend.array(backend.splice(source, mapping, True))
    for count in (1, 2):
        poisoned = [(k.clone(), v.clone()) for k, v in source]
        for k, v in poisoned[:count]:
            k[:] = float("nan")
            v[:] = float("nan")
        kv, selected = construct(
            backend,
            poisoned,
            mapping,
            ids,
            mandatory,
            candidates,
            None,
            0,
            1,
            f"early_layers{count}",
            0,
        )
        actual = backend.array(kv)
        assert np.isfinite(actual).all()
        assert selected == mandatory
        np.testing.assert_allclose(actual[:count], cold[:count], atol=1e-6, rtol=1e-5)
        np.testing.assert_array_equal(
            actual[count:][:, :, candidates], rope[count:][:, :, candidates]
        )
    all_layers = len(source)
    base = backend.splice(source, mapping, True, skip_layers=all_layers)
    kv, _ = backend.recompute(base, ids, mandatory, refresh_layers=all_layers)
    np.testing.assert_allclose(backend.array(kv), cold, atol=1e-6, rtol=1e-5)


def test_chunk_repair_does_not_read_selected_kv(spec, backend):
    from benchmarks.sparse_bench.backend import select_gap_chunks
    from benchmarks.sparse_bench.cases import deletion_anchors
    from benchmarks.sparse_bench.runner import construct

    text, spans = render(spec, [0, 1, 2])
    source_tokens = tokenize(backend.tokenizer, text, spans)
    source = backend.prefill([t["id"] for t in source_tokens])
    text, spans = render(spec, [0, 2])
    tokens = tokenize(backend.tokenizer, text, spans)
    ids = [t["id"] for t in tokens]
    mapping = align(source_tokens, tokens)
    mandatory = [i for i, src in enumerate(mapping) if src < 0]
    candidates = [i for i, src in enumerate(mapping) if src >= 0]
    anchors = deletion_anchors(spec, {"kept": [0, 2], "removed": [1]}, tokens)
    selected = sorted(set(mandatory + select_gap_chunks(len(ids), anchors, 16)))
    expected, _ = backend.recompute(
        backend.splice(source, mapping, True), ids, selected
    )
    # Poison every skipped source slot. Any accidental use propagates NaNs.
    poisoned = [(k.clone(), v.clone()) for k, v in source]
    skipped_source = [mapping[i] for i in selected if mapping[i] >= 0]
    for k, v in poisoned:
        k[:, :, skipped_source] = float("nan")
        v[:, :, skipped_source] = float("nan")
    actual, chosen = construct(
        backend,
        poisoned,
        mapping,
        ids,
        mandatory,
        candidates,
        None,
        0,
        1,
        "gap_chunk16",
        0,
        gap_anchors=anchors,
    )
    assert chosen == selected
    np.testing.assert_allclose(
        backend.array(actual), backend.array(expected), atol=1e-6, rtol=1e-5
    )
    # The reference batches selected queries by layer. Verify it represents
    # processing consecutive repair chunks from left to right with mixed KV.
    streamed = backend.splice(source, mapping, True, skip_positions=selected)
    ranges = []
    for pos in selected:
        if ranges and ranges[-1][-1] + 1 == pos:
            ranges[-1].append(pos)
        else:
            ranges.append([pos])
    for positions in ranges:
        streamed, _ = backend.recompute(streamed, ids, positions)
    np.testing.assert_allclose(
        backend.array(streamed), backend.array(actual), atol=1e-6, rtol=1e-5
    )
    # An oversized deletion window covers the complete affected suffix. With
    # exact preceding context it must recover cold, despite skipped source KV.
    complete = sorted(set(mandatory + list(range(min(anchors), len(ids)))))
    base = backend.splice(source, mapping, True, skip_positions=complete)
    recovered, _ = backend.recompute(base, ids, complete)
    np.testing.assert_allclose(
        backend.array(recovered),
        backend.array(backend.prefill(ids)),
        atol=1e-6,
        rtol=1e-5,
    )


def test_superset_gradient_profiles_and_finite_difference(spec, backend):
    import math

    import torch

    from benchmarks.sparse_bench.runner import construct
    from benchmarks.sparse_bench.saliency import (
        build_profiles,
        prefix_loss,
        target_weights,
    )

    text, spans = render(spec, [0, 1, 2])
    tokens = tokenize(backend.tokenizer, text, spans)
    ids = [t["id"] for t in tokens]
    source = backend.prefill(ids)
    profiles, diagnostic, metadata = build_profiles(backend, ids, tokens, source)
    assert len(profiles) == 9 and len(diagnostic) == 9
    assert not metadata["uses_subset_gt"] and not metadata["uses_queries"]
    assert all(np.isfinite(p).all() and (p >= 0).all() for p in profiles.values())
    assert all(parameter.grad is None for parameter in backend.model.parameters())
    weights = target_weights(tokens, "all", backend.device)
    leaves = [
        (k.clone().requires_grad_(), v.clone().requires_grad_()) for k, v in source
    ]
    loss = prefix_loss(backend, ids, leaves, weights)
    grad = torch.autograd.grad(loss, leaves[0][1])[0]
    index = int(grad.abs().reshape(-1).argmax())
    epsilon = 0.005
    losses = []
    for sign in (-1, 1):
        perturbed = [(k.clone(), v.clone()) for k, v in source]
        perturbed[0][1].reshape(-1)[index] += sign * epsilon
        with torch.no_grad():
            losses.append(float(prefix_loss(backend, ids, perturbed, weights)))
    numerical = (losses[1] - losses[0]) / (2 * epsilon)
    assert numerical == pytest.approx(
        float(grad.reshape(-1)[index]), rel=0.05, abs=2e-4
    )
    mapping = list(range(len(ids)))
    for method in ("grad_all_scaled", "grad_tools_scaled_affected", "grad_blend_soft"):
        edited, chosen = construct(
            backend,
            source,
            mapping,
            ids,
            [],
            mapping,
            None,
            0,
            1,
            method,
            0.15,
            None,
            [],
            profiles,
        )
        assert len(chosen) == math.ceil(0.15 * len(ids))


def test_delta_rotation_roundtrip_and_v_unchanged(spec, backend):
    text, spans = render(spec, [0, 1, 2])
    source_tokens = tokenize(backend.tokenizer, text, spans)
    source = backend.prefill([t["id"] for t in source_tokens])
    mapping = list(range(len(source_tokens)))
    identical = backend.splice(source, mapping, True)
    np.testing.assert_array_equal(backend.array(source), backend.array(identical))
    subset = mapping[5:]
    rotated = backend.splice(source, subset, True)
    unrotated = backend.splice(source, subset, False)
    np.testing.assert_array_equal(
        backend.array(rotated)[:, 1], backend.array(unrotated)[:, 1]
    )


def run_args(manifest, out):
    from benchmarks.sparse_bench.__main__ import parser

    return parser().parse_args(
        [
            "run",
            "--manifest",
            str(manifest),
            "--out",
            str(out),
            "--methods",
            "exact",
            "splice",
            "rope",
            "random",
            "gap",
            "gap_chunk16",
            "early_layers1",
            "oracle_diff",
            "oracle_copy",
            "early_key",
            "cacheblend_superset",
            "cacheblend_independent",
            "grad_all_scaled",
            "grad_tools_scaled",
            "grad_blend_soft",
            "--budgets",
            "0",
            ".3",
            "1",
            "--masks",
            "m0,m1,m2,m3,m4,m5,m6,m7",
            "--repeats",
            "1",
            "--threads",
            "1",
            "--max-tokens",
            "3",
            "--include-absent",
            "--heads",
            "--save-kv",
            "all",
        ]
    )


def test_pipeline_artifacts_quality_and_report(spec, backend, tmp_path):
    from benchmarks.sparse_bench.report import report
    from benchmarks.sparse_bench.runner import execute

    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps(make_manifest(spec)))
    root = tmp_path / "run"
    execute(run_args(manifest, root), backend)
    run = json.loads((root / "run.json").read_text())
    assert run["status"] == "complete"
    case = root / "cases" / "m5"
    assert (case / "quality.json").exists()
    with np.load(case / "rope" / "kv.npz") as data:
        assert data["kv"].ndim == 5 and data["kv"].shape[1] == 2
    gates = json.loads((case / "gates.json").read_text())
    assert any(
        g["name"] == "exact_vs_native_continuation" and g["passed"] for g in gates
    )
    assert any(
        g["name"] == "early_layers1_fresh_layers_vs_cold" and g["passed"] for g in gates
    )
    assert (
        json.loads((case / "oracle_diff@1" / "metrics.json").read_text())["overall"][
            "k"
        ]["relative_l2"]
        < 1e-5
    )
    assert (
        json.loads((case / "oracle_copy@1" / "metrics.json").read_text())["overall"][
            "k"
        ]["relative_l2"]
        < 1e-5
    )
    out = tmp_path / "report"
    summary = report(
        Namespace(
            run=str(root),
            out=str(out),
            detail_limit=2,
            detail_masks=None,
            export_tokens=True,
        )
    )
    assert summary["coverage_of_all_masks"] == 1
    assert summary["layer_error_energy"]["partial_masks"] == 6
    assert (out / "layer_error_energy.csv").is_file()
    assert (out / "tokens.csv").stat().st_size > 1000
    assert (out / "summary.png").exists() and (out / "tokens.png").exists()
    assert (out / "block_impact.png").exists()
    assert "__PAYLOAD__" not in (out / "index.html").read_text()
    assert summary["quality"]["cold"]["absent"]["cases"] == 8
    view = json.loads((out / "view.json").read_text())
    assert view["cases"]["m5"]["mask"]["removed"] == [1]
    assert view["quality"] and view["spec"]["tools"]
    chunk_rows = [r for r in view["rows"] if r["method"] == "gap_chunk16"]
    assert len(chunk_rows) == 8
    assert all(
        r["kv_loaded_tokens"] + r["selected_eligible_tokens"]
        == r["reuse_eligible_tokens"]
        for r in chunk_rows
    )
    assert any(d["method"] == "gap_chunk16" for d in view["details"])
    layer_rows = [r for r in view["rows"] if r["method"] == "early_layers1"]
    assert len(layer_rows) == 8
    assert all(
        r["recomputed_token_layers"] + r["kv_loaded_token_layers"]
        == r["tokens"] * backend.model.config.num_hidden_layers
        for r in layer_rows
    )
    assert any(d["method"] == "early_layers1" for d in view["details"])
    document = (out / "index.html").read_text()
    assert "실험 구성" in document
    assert "All measured masks" not in document
    assert 'id="toolCompare"' not in document
    assert 'id="assemblyCase"' in document
    assert 'id="correctionCharts"' not in document
    # Runs share a page, but retain separate rows and statistical denominators.
    other = tmp_path / "second-run"
    shutil.copytree(root, other)
    combined = tmp_path / "combined"
    args = Namespace(
        run=str(root),
        also_run=[str(other)],
        out=str(combined),
        detail_limit=1,
        detail_masks=None,
        export_tokens=False,
    )
    merged = report(args)
    assert merged["unique_masks"] == 8
    assert len(merged["runs"]) == 2
    assert (combined / "data" / "run-2" / "blocks.csv").exists()
    # A KV-only run may have an unused generation length; quality runs must agree.
    other_meta = json.loads((other / "run.json").read_text())
    other_meta["config"]["max_tokens"] += 1
    (other / "run.json").write_text(json.dumps(other_meta))
    args.out = str(tmp_path / "incompatible")
    with pytest.raises(ValueError, match="generation lengths"):
        report(args)
    # Output reuse must never silently overwrite a completed measurement.
    with pytest.raises(ValueError, match="empty"):
        execute(run_args(manifest, root), backend)
    metrics = case / "rope" / "metrics.json"
    metrics.write_text(metrics.read_text() + " ")
    with pytest.raises(ValueError, match="checksum"):
        report(
            Namespace(
                run=str(root),
                out=str(tmp_path / "tampered"),
                detail_limit=0,
                detail_masks=None,
                export_tokens=False,
            )
        )


def test_failed_run_is_not_reportable(spec, backend, tmp_path, monkeypatch):
    from benchmarks.sparse_bench.report import report
    from benchmarks.sparse_bench.runner import execute

    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps(make_manifest(spec)))
    root = tmp_path / "bad"
    monkeypatch.setattr(
        backend, "prefill", lambda _: (_ for _ in ()).throw(RuntimeError("injected"))
    )
    with pytest.raises(RuntimeError, match="injected"):
        execute(run_args(manifest, root), backend)
    assert json.loads((root / "run.json").read_text())["status"] == "failed"
    with pytest.raises(ValueError, match="completed"):
        report(Namespace(run=str(root), out=str(tmp_path / "report")))
