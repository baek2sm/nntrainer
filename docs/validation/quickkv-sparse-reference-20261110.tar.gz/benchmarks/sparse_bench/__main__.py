"""python -m benchmarks.sparse_bench {plan,run,report}"""

import argparse
import json
from pathlib import Path


def parser():
    p = argparse.ArgumentParser(description=__doc__)
    commands = p.add_subparsers(dest="command", required=True)
    plan = commands.add_parser(
        "plan", help="write an exhaustive, hashed workload without loading a model"
    )
    plan.add_argument(
        "--spec", default=str(Path(__file__).with_name("device_tools.json"))
    )
    plan.add_argument("--out", required=True)
    plan.add_argument("--seed", type=int, default=0)
    run = commands.add_parser(
        "run", help="HF Qwen3 eager reference measurements; local model files only"
    )
    run.add_argument("--manifest", required=True)
    run.add_argument("--out", required=True)
    run.add_argument(
        "--resume",
        action="store_true",
        help="verify and reuse completed cases in this run",
    )
    run.add_argument("--model", default="Qwen/Qwen3-0.6B")
    run.add_argument("--revision", default="main")
    run.add_argument("--device", default="cpu")
    run.add_argument(
        "--dtype", choices=["float32", "float16", "bfloat16"], default="float32"
    )
    run.add_argument("--methods", nargs="+", default=["exact", "splice", "rope"])
    run.add_argument(
        "--budgets", type=float, nargs="+", default=[0, 0.05, 0.15, 0.30, 1]
    )
    run.add_argument("--check-layer", type=int, default=1)
    run.add_argument("--repeats", type=int, default=3)
    run.add_argument("--threads", type=int, default=4)
    run.add_argument(
        "--selection-seed",
        type=int,
        default=0,
        help="random-policy seed; does not change manifest splits",
    )
    run.add_argument(
        "--atol", type=float, default=1e-5, help="absolute KV integrity tolerance"
    )
    run.add_argument("--logit-atol", type=float, default=1e-4)
    run.add_argument("--rtol", type=float, default=1e-4)
    run.add_argument("--split", choices=["all", "train", "dev", "test"], default="all")
    run.add_argument("--masks", help="comma-separated mask IDs from manifest")
    run.add_argument("--limit", type=int)
    run.add_argument("--shards", type=int, default=1)
    run.add_argument("--shard-index", type=int, default=0)
    run.add_argument("--kv-only", action="store_true")
    run.add_argument("--include-absent", action="store_true")
    run.add_argument(
        "--query-families", nargs="+", help="evaluate only these query families"
    )
    run.add_argument(
        "--query-limit", type=int, help="smoke-test only; biased prefix of query list"
    )
    run.add_argument("--max-tokens", type=int, default=32)
    run.add_argument(
        "--min-reference-tokens",
        type=int,
        default=0,
        help="fail a long-trace run if cold stops before this length",
    )
    run.add_argument(
        "--token-level", action=argparse.BooleanOptionalAction, default=True
    )
    run.add_argument(
        "--heads",
        action="store_true",
        help="also retain per-head sufficient statistics",
    )
    run.add_argument(
        "--save-kv",
        choices=["none", "reference", "all"],
        default="none",
        help="optional vector dumps; can require tens of GB for all masks",
    )
    report = commands.add_parser(
        "report", help="offline HTML, PNG and CSV from successful case artifacts"
    )
    report.add_argument("--run", required=True)
    report.add_argument(
        "--also-run", nargs="+", help="additional compatible runs in one report"
    )
    report.add_argument("--out", required=True)
    report.add_argument("--detail-limit", type=int, default=8)
    report.add_argument(
        "--detail-methods",
        nargs="+",
        default=["all"],
        help="methods to embed as token views, or all",
    )
    report.add_argument(
        "--detail-masks",
        help="comma-separated IDs, overrides automatic worst-rope selection",
    )
    report.add_argument(
        "--export-tokens",
        action="store_true",
        help="stream all per-layer/token data to CSV",
    )
    return p


def main():
    args = parser().parse_args()
    if args.command == "plan":
        from .cases import make_manifest

        out = Path(args.out)
        if out.exists():
            raise ValueError("manifest already exists; choose another path")
        manifest = make_manifest(json.loads(Path(args.spec).read_text()), args.seed)
        out.parent.mkdir(parents=True, exist_ok=True)
        with out.open("x") as stream:
            json.dump(manifest, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        print(f"{out}: {len(manifest['masks'])} masks; sha256={manifest['sha256']}")
    elif args.command == "run":
        from .runner import execute

        execute(args)
    else:
        from .report import report

        report(args)


if __name__ == "__main__":
    main()
