"""Offline reports. Never reinterpret legacy summaries as comparable measurements."""

import csv
import html
import json
from collections import defaultdict
from pathlib import Path

import numpy as np

from .cases import read_manifest
from .metrics import relative, token_preservation


def read(path):
    return json.loads(path.read_text())


def display_matrix(array):
    """Six significant digits for embedded figures; raw NPZ/CSV stay untouched."""
    return [[[float(f"{v:.6g}") for v in row] for row in layer] for layer in array]


def enrich_token_pieces(run, source, quality):
    """Decode display pieces only after matching the recorded source tokenizer."""
    try:
        from huggingface_hub import try_to_load_from_cache
        from tokenizers import Tokenizer
    except ImportError:
        return
    local = Path(run["config"]["model"]) / "tokenizer.json"
    path = (
        str(local)
        if local.is_file()
        else try_to_load_from_cache(
            run["config"]["model"],
            "tokenizer.json",
            revision=run["provenance"].get("model_commit") or run["config"]["revision"],
        )
    )
    if not isinstance(path, str) or not Path(path).is_file():
        return
    tokenizer = Tokenizer.from_file(path)
    if any(
        tokenizer.decode([t["id"]], skip_special_tokens=False) != t["piece"]
        for t in source
    ):
        return
    for row in quality:
        row["token_pieces"] = [
            tokenizer.decode([t], skip_special_tokens=False) for t in row["tokens"]
        ]


def write_csv(path, rows, fields=None):
    with path.open("w", newline="") as stream:
        if fields is None:
            rows = list(rows)
            fields = list(dict.fromkeys(k for row in rows for k in row))
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow(
                {
                    k: json.dumps(v, ensure_ascii=False)
                    if isinstance(v, (dict, list))
                    else v
                    for k, v in row.items()
                }
            )


def aggregate(rows):
    result = {}
    for method in sorted({r["method"] for r in rows}):
        group = [r for r in rows if r["method"] == method]
        result[method] = {"masks": len(group)}
        for kind in ("k", "v"):
            errors = sum(r["overall"][kind]["error_sq"] for r in group)
            refs = sum(r["overall"][kind]["reference_sq"] for r in group)
            vals = [
                r["overall"][kind]["relative_l2"]
                for r in group
                if r["overall"][kind]["relative_l2"] is not None
            ]
            result[method][kind] = {
                "pooled_relative_l2": relative(errors, refs),
                "macro_mask_relative_l2": float(np.mean(vals)) if vals else None,
                "p95_mask_relative_l2": float(np.percentile(vals, 95))
                if vals
                else None,
                "worst_mask_relative_l2": max(vals) if vals else None,
            }
    return result


def layer_error_energy(root, out, cases, tool_count):
    """Export where the RoPE baseline's residual error is located by layer."""
    energy, masks = None, 0
    for mask, case in cases.items():
        if not 0 < len(case["mask"]["kept"]) < tool_count:
            continue
        path = root / "cases" / mask / "rope" / "stats.npz"
        if not path.exists():
            continue
        with np.load(path, allow_pickle=False) as data:
            value = data["error_sq"].sum(axis=-1)
        energy = value if energy is None else energy + value
        masks += 1
    if energy is None:
        return None
    total = energy.sum(axis=0)
    cumulative = energy.cumsum(axis=0)
    write_csv(
        out / "layer_error_energy.csv",
        [
            {
                "layer": layer,
                "partial_masks": masks,
                "reference_method": "rope",
                **{
                    f"{kind}_{metric}": float(value) if value is not None else None
                    for channel, kind in enumerate(("k", "v"))
                    for metric, value in (
                        ("error_sq", energy[layer, channel]),
                        (
                            "error_energy_fraction",
                            energy[layer, channel] / total[channel]
                            if total[channel]
                            else None,
                        ),
                        (
                            "cumulative_error_energy_fraction",
                            cumulative[layer, channel] / total[channel]
                            if total[channel]
                            else None,
                        ),
                    )
                },
            }
            for layer in range(len(energy))
        ],
    )
    return {
        "file": "layer_error_energy.csv",
        "partial_masks": masks,
        "scope": (
            "RoPE residual squared error; summed over partial masks and prefix tokens"
        ),
    }


def paired_quality(rows):
    result = {}
    for method in sorted({r["method"] for r in rows}):
        group = [r for r in rows if r["method"] == method]
        # Also group by presence; accuracy on no-tool cases is a distinct task.
        result[method] = {}
        for present in (True, False):
            subset = [r for r in group if r["target_present"] == present]
            if not subset:
                continue
            by_mask = defaultdict(list)
            for r in subset:
                by_mask[r["mask"]].append(
                    float(r["correct"]) - float(r["cold_correct"])
                )
            # Resample masks; tokens, layers and queries are not independent trials.
            sums = np.array([sum(v) for v in by_mask.values()])
            counts = np.array([len(v) for v in by_mask.values()])
            rng = np.random.default_rng(0)
            draws = [rng.integers(len(sums), size=len(sums)) for _ in range(1000)]
            delta = [sums[d].sum() / counts[d].sum() for d in draws]
            result[method]["present" if present else "absent"] = {
                "cases": len(subset),
                "mask_clusters": len(sums),
                "accuracy": float(np.mean([r["correct"] for r in subset])),
                "format_valid_rate": float(
                    np.mean([r["format_valid"] for r in subset])
                ),
                "cold_accuracy": float(np.mean([r["cold_correct"] for r in subset])),
                "cold_correct_to_wrong": sum(
                    r["cold_correct"] and not r["correct"] for r in subset
                ),
                "cold_wrong_to_correct": sum(
                    not r["cold_correct"] and r["correct"] for r in subset
                ),
                "same_as_cold": float(np.mean([r["same_as_cold"] for r in subset])),
                "mean_common_prefix_fraction": float(
                    np.mean([r["common_prefix_fraction"] for r in subset])
                ),
                "mean_position_match_fraction": float(
                    np.mean([r["position_match_fraction"] for r in subset])
                ),
                "mean_cold_generated_tokens": float(
                    np.mean([r["cold_generated_tokens"] for r in subset])
                ),
                "paired_accuracy_delta_ci95_by_mask": np.percentile(
                    delta, [2.5, 97.5]
                ).tolist()
                if len(sums) >= 2
                else None,
                "ci_scope": (
                    "conditional on this fixed template and query set; masks resampled"
                ),
            }
    return result


def token_rows(case, name, arrays):
    # NpzFile decompresses on every __getitem__; materialize each array once.
    error_sq, reference_sq = arrays["error_sq"], arrays["reference_sq"]
    for layer in range(error_sq.shape[0]):
        for channel, kind in enumerate(("k", "v")):
            for token in case["tokens"]:
                pos = token["position"]
                error = float(error_sq[layer, channel, pos])
                ref = float(reference_sq[layer, channel, pos])
                yield {
                    "mask": case["mask"]["id"],
                    "method": name,
                    "layer": layer,
                    "kind": kind,
                    "block": token["block"],
                    "position": pos,
                    "within_block": token["within_block"],
                    "token_id": token["id"],
                    "piece": token["piece"],
                    "source_position": token["source_position"],
                    "mandatory_recompute": token["mandatory_recompute"],
                    "error_sq": error,
                    "reference_sq": ref,
                    "relative_l2": relative(error, ref),
                }


def report(args):
    if getattr(args, "also_run", None):
        return integrated_report(args)
    root, out = Path(args.run), Path(args.out)
    if root.resolve() == out.resolve() or root.resolve() in out.resolve().parents:
        raise ValueError("report output must be outside raw run artifacts")
    run = read(root / "run.json")
    manifest = read_manifest(root / "manifest.json")
    if manifest["sha256"] != run["manifest_sha256"]:
        raise ValueError("run manifest mismatch")
    if run["status"] != "complete":
        raise ValueError(
            "only completed runs can be reported; failed/partial runs are not evidence"
        )
    out.mkdir(parents=True, exist_ok=True)
    if any(out.iterdir()):
        raise ValueError("report output directory must be empty")
    rows, quality, cases, flat, blocks = [], [], {}, [], []
    for mask in run["mask_ids"]:
        path = root / "cases" / mask
        marker = read(path / "complete.json")
        if marker["manifest_sha256"] != run["manifest_sha256"]:
            raise ValueError("case manifest mismatch")
        if marker.get("files"):
            import hashlib

            for name, checksum in marker["files"].items():
                file = path / name
                if file.resolve().is_relative_to(path.resolve()) is False:
                    raise ValueError("invalid case artifact path")
                if hashlib.sha256(file.read_bytes()).hexdigest() != checksum:
                    raise ValueError(f"case artifact checksum mismatch: {mask}/{name}")
        case = read(path / "case.json")
        cases[mask] = case
        for file in sorted(path.glob("*/metrics.json")):
            row = read(file)
            row["mask"], row["split"] = mask, case["mask"]["split"]
            rows.append(row)
            flat.append(
                {
                    "mask": mask,
                    "split": row["split"],
                    "method": row["method"],
                    **row["features"],
                    "tokens": row["overall"]["tokens"],
                    "k_relative_l2": row["overall"]["k"]["relative_l2"],
                    "v_relative_l2": row["overall"]["v"]["relative_l2"],
                    "construction_median_ms": row["timing"]["median_ms"],
                    "selected_eligible_tokens": row["selected_eligible_tokens"],
                    "early_full_prefix_layers": row["early_full_prefix_layers"],
                    "selector_variant": row.get("selector_variant"),
                    "oracle": row["oracle"],
                    "storage_context": row.get(
                        "storage_context", "superset_sequential"
                    ),
                    **{
                        k: row[k]
                        for k in (
                            "chunk_tokens_per_gap",
                            "recompute_ranges",
                            "kv_loaded_tokens",
                            "kv_read_bytes",
                            "kv_read_avoided_bytes",
                            "io_scope",
                            "recomputed_prefix_layers",
                            "recomputed_token_layers",
                            "kv_loaded_token_layers",
                            "late_boundary_repair",
                        )
                        if k in row
                    },
                }
            )
            for block, value in row["blocks"].items():
                blocks.append(
                    {
                        "mask": mask,
                        "method": row["method"],
                        "block": block,
                        "tokens": value["tokens"],
                        **{
                            f"{kind}_{metric}": value[kind][metric]
                            for kind in ("k", "v")
                            for metric in ("relative_l2", "error_sq", "reference_sq")
                        },
                    }
                )
        if (path / "quality.json").exists():
            quality.extend(read(path / "quality.json"))
    cold = {
        (q["mask"], q["query"]): q["tokens"] for q in quality if q["method"] == "cold"
    }
    for q in quality:
        q.update(token_preservation(cold[q["mask"], q["query"]], q["tokens"]))
    layer_energy = layer_error_energy(root, out, cases, len(manifest["spec"]["tools"]))
    summary = {
        "manifest_sha256": run["manifest_sha256"],
        "masks": len(cases),
        "measured_mask_query_pairs": len({(r["mask"], r["query"]) for r in quality}),
        "coverage_of_all_masks": len(cases)
        / len(read(root / "manifest.json")["masks"]),
        "overall": aggregate(rows),
        "by_removed_tools": {
            str(n): aggregate([r for r in rows if r["features"]["removed_tools"] == n])
            for n in sorted({r["features"]["removed_tools"] for r in rows})
        },
        "quality": paired_quality(quality),
        "by_split": {
            split: {
                "kv": aggregate([r for r in rows if r["split"] == split]),
                "quality": paired_quality([q for q in quality if q["split"] == split]),
            }
            for split in sorted({r["split"] for r in rows})
        },
        "native_exact_numerical_floors": {
            mask: case["native_exact_vs_cold_numerical_floor"]
            for mask, case in cases.items()
        },
        "run_config": run["config"],
        "provenance": run["provenance"],
        "offline_gradient": run.get("offline_gradient"),
        "layer_error_energy": layer_energy,
        "execution": run["execution"],
        "limitations": [
            "one template; mask coverage is not model/template generalization",
            "construction timing is an HF eager reference, not serving TTFT",
            "oracle selection/replacement excludes offline cold reference preparation",
            (
                "tune on train/dev masks only; query-family and template "
                "generalization need separate held-out workloads"
            ),
        ],
    }
    (out / "summary.json").write_text(
        json.dumps(summary, indent=2, allow_nan=False) + "\n"
    )
    write_csv(out / "masks.csv", flat)
    write_csv(out / "blocks.csv", blocks)
    if quality:
        quality_index = defaultdict(list)
        for q in quality:
            quality_index[q["mask"], q["method"]].append(q)
        write_csv(
            out / "quality.csv",
            [
                dict(
                    {
                        k: v
                        for k, v in r.items()
                        if k not in ("teacher_forced", "tokens")
                    },
                    teacher_tvd_mean=float(np.mean(r["teacher_forced"]["tvd"])),
                    teacher_tvd_max=max(r["teacher_forced"]["tvd"]),
                    teacher_kl_mean=float(
                        np.mean(r["teacher_forced"]["kl_cold_to_arm"])
                    ),
                    teacher_argmax_agree=float(
                        np.mean(r["teacher_forced"]["argmax_agree"])
                    ),
                )
                for r in quality
            ],
        )
        write_csv(
            out / "kv_quality.csv",
            [
                dict(
                    f,
                    **{
                        k: q[k]
                        for k in (
                            "query",
                            "query_family",
                            "target_present",
                            "correct",
                            "cold_correct",
                            "same_as_cold",
                            "common_prefix_tokens",
                            "common_prefix_fraction",
                            "position_match_fraction",
                        )
                    },
                    teacher_tvd_mean=float(np.mean(q["teacher_forced"]["tvd"])),
                )
                for f in flat
                for q in quality_index[f["mask"], f["method"]]
            ],
        )
    requested = args.detail_masks.split(",") if args.detail_masks else None
    if requested and set(requested) - set(cases):
        raise ValueError("detail mask was not measured")
    # Selection is for display only. Aggregate/CSV always contains every measured mask.
    ranking = sorted(
        cases,
        key=lambda m: (
            -max(
                [
                    r["overall"]["k"]["relative_l2"] or 0
                    for r in rows
                    if r["mask"] == m and r["policy"] == "rope"
                ]
                or [0]
            )
        ),
    )
    detail_masks = (
        requested if requested is not None else ranking[: max(0, args.detail_limit)]
    )
    details = []
    detail_methods = getattr(args, "detail_methods", ["all"])
    detail_order = {mask: i for i, mask in enumerate(detail_masks)}
    for row in sorted(
        rows, key=lambda r: detail_order.get(r["mask"], len(detail_masks))
    ):
        if row["mask"] not in detail_masks:
            continue
        kept = len(cases[row["mask"]]["mask"]["kept"])
        if kept == 0 or kept == len(manifest["spec"]["tools"]):
            continue
        if row["policy"] in ("cold", "exact"):
            continue
        if not row["policy"].startswith(("grad_", "gap_chunk", "early_layers")) and row[
            "policy"
        ] not in (
            "splice",
            "rope",
            "gap",
            "cacheblend_independent",
            "cacheblend_superset",
        ):
            continue
        if (
            row["policy"] not in ("splice", "rope")
            and not row["policy"].startswith(("gap_chunk", "early_layers"))
            and not 0 < row["budget_fraction"] < 1
        ):
            continue
        if "all" not in detail_methods and row["method"] not in detail_methods:
            continue
        file = root / "cases" / row["mask"] / row["method"] / "stats.npz"
        if not file.exists():
            continue
        with np.load(file, allow_pickle=False) as arrays:
            details.append(
                {
                    "mask": row["mask"],
                    "method": row["method"],
                    "tokens": cases[row["mask"]]["tokens"],
                    "selected": row["selected_positions"],
                    "early_full_prefix_layers": row["early_full_prefix_layers"],
                    "error_sq": display_matrix(arrays["error_sq"]),
                    "reference_sq": display_matrix(arrays["reference_sq"]),
                    "presentation_significant_digits": 6,
                }
            )
    if args.export_tokens:
        fields = [
            "mask",
            "method",
            "layer",
            "kind",
            "block",
            "position",
            "within_block",
            "token_id",
            "piece",
            "source_position",
            "mandatory_recompute",
            "error_sq",
            "reference_sq",
            "relative_l2",
        ]

        def all_tokens():
            for row in rows:
                file = root / "cases" / row["mask"] / row["method"] / "stats.npz"
                if file.exists():
                    with np.load(file, allow_pickle=False) as arrays:
                        yield from token_rows(cases[row["mask"]], row["method"], arrays)

        write_csv(out / "tokens.csv", all_tokens(), fields)
    importance = {}
    if run.get("offline_gradient"):
        source = read(root / "source_tokens.json")
        with np.load(root / "superset_saliency.npz", allow_pickle=False) as profiles:
            importance = {
                key: profiles[key].tolist()
                for key in profiles.files
                if profiles[key].ndim == 1
            }
        write_csv(
            out / "superset_importance.csv",
            [
                {
                    "position": t["position"],
                    "block": t["block"],
                    "token_id": t["id"],
                    "piece": t["piece"],
                    **{key: vals[t["position"]] for key, vals in importance.items()},
                }
                for t in source
            ],
        )
    make_png(out, rows, details, cases, read(root / "manifest.json")["spec"])
    enrich_token_pieces(run, read(root / "source_tokens.json"), quality)
    case_tokens, reference_sq = {}, {}
    for detail in details:
        case_tokens.setdefault(detail["mask"], detail.pop("tokens"))
        reference_sq.setdefault(detail["mask"], detail.pop("reference_sq"))
    view = {
        "id": root.name,
        "summary": summary,
        "rows": flat,
        "blocks": blocks,
        "details": details,
        "quality": quality,
        "spec": manifest["spec"],
        "cases": {
            mask: {k: v for k, v in case.items() if k != "tokens"}
            | {"token_count": len(case["tokens"])}
            for mask, case in cases.items()
        },
        "downloads": "",
        "case_tokens": case_tokens,
        "reference_sq": reference_sq,
        "superset_importance": importance,
    }
    (out / "view.json").write_text(
        json.dumps(view, ensure_ascii=False, allow_nan=False)
    )
    payload = json.dumps(
        {"experiments": [view]},
        ensure_ascii=True,
        allow_nan=False,
    ).replace("<", "\\u003c")
    template = Path(__file__).with_name("report.html").read_text()
    document = template.replace("__TITLE__", html.escape(root.name)).replace(
        "__PAYLOAD__", payload
    )
    (out / "index.html").write_text(document)
    print(
        f"{out / 'index.html'}: {len(cases)} masks, "
        f"{len(rows)} method/mask rows, {len(details)} token views"
    )
    return summary


def integrated_report(args):
    """Keep run identity and denominators separate while presenting one document."""
    from argparse import Namespace

    roots = [Path(args.run), *map(Path, args.also_run)]
    if len({p.resolve() for p in roots}) != len(roots):
        raise ValueError("duplicate runs in integrated report")
    manifests = [read_manifest(p / "manifest.json") for p in roots]
    if len({m["sha256"] for m in manifests}) != 1:
        raise ValueError("integrated runs must use the same manifest")
    runs = [read(p / "run.json") for p in roots]
    keys = ("model", "revision", "dtype", "device", "check_layer", "selection_seed")
    first = runs[0]
    for run in runs:
        if run["status"] != "complete":
            raise ValueError("only completed runs can be reported")
        if any(run["config"].get(k) != first["config"].get(k) for k in keys):
            raise ValueError(
                "incompatible model, execution or generation configuration"
            )
        for key in ("tokenizer_sha256", "model_commit", "model_config", "packages"):
            if run["provenance"].get(key) != first["provenance"].get(key):
                raise ValueError(f"incompatible run provenance: {key}")
    quality_runs = [r for r in runs if not r["config"].get("kv_only")]
    if len({r["config"]["max_tokens"] for r in quality_runs}) > 1:
        raise ValueError("incompatible generation lengths in quality runs")
    out = Path(args.out)
    if any(
        out.resolve() == p.resolve() or p.resolve() in out.resolve().parents
        for p in roots
    ):
        raise ValueError("report output must be outside raw run artifacts")
    out.mkdir(parents=True, exist_ok=True)
    if any(out.iterdir()):
        raise ValueError("report output directory must be empty")
    experiments = []
    for i, root in enumerate(roots):
        child = out / "data" / f"run-{i + 1}"
        config = vars(args) | {"run": str(root), "out": str(child), "also_run": None}
        # Requested detail IDs may belong to only one of the included runs.
        requested = config.get("detail_masks")
        if requested:
            ids = set(runs[i]["mask_ids"])
            selected = [m for m in requested.split(",") if m in ids]
            config["detail_masks"] = ",".join(selected) if selected else None
        report(Namespace(**config))
        view = read(child / "view.json")
        view["id"] = f"run-{i + 1}"
        view["downloads"] = f"data/run-{i + 1}/"
        experiments.append(view)
    seen_details = set()
    for view in experiments:
        unique = []
        for detail in view["details"]:
            key = detail["mask"], detail["method"]
            if key not in seen_details:
                unique.append(detail)
                seen_details.add(key)
        view["details"] = unique
    payload = json.dumps(
        {"experiments": experiments}, ensure_ascii=False, allow_nan=False
    ).replace("<", "\\u003c")
    template = Path(__file__).with_name("report.html").read_text()
    (out / "index.html").write_text(
        template.replace("__TITLE__", "실험 통합 리포트").replace(
            "__PAYLOAD__", payload
        )
    )
    summary = {
        "runs": [e["summary"] for e in experiments],
        "unique_masks": len({m for e in experiments for m in e["cases"]}),
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False))
    print(f"{out / 'index.html'}: integrated {len(experiments)} runs")
    return summary


def make_png(out, rows, details, cases, spec):
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 2, figsize=(12, 4), constrained_layout=True)
    for channel, kind in enumerate(("k", "v")):
        for method in sorted({r["method"] for r in rows}):
            group = [r for r in rows if r["method"] == method]
            counts = sorted({r["features"]["removed_tools"] for r in group})
            values = []
            for n in counts:
                subset = [r for r in group if r["features"]["removed_tools"] == n]
                values.append(
                    relative(
                        sum(r["overall"][kind]["error_sq"] for r in subset),
                        sum(r["overall"][kind]["reference_sq"] for r in subset),
                    )
                )
            axes[channel].plot(counts, values, marker=".", label=method)
        axes[channel].set(
            xlabel="Removed tools",
            ylabel=f"{kind.upper()} pooled relative L2",
            title="Measured masks only; energy-weighted",
        )
        axes[channel].grid(alpha=0.2)
    axes[-1].legend(fontsize=7, loc="upper left", bbox_to_anchor=(1, 1))
    fig.savefig(out / "summary.png", dpi=160)
    plt.close(fig)
    method = "rope" if any(r["method"] == "rope" for r in rows) else "exact"
    selected = [
        r for r in rows if r["method"] == method and r["features"]["removed_tools"] == 1
    ]
    loo = bool(selected)
    selected = selected or [r for r in rows if r["method"] == method][:20]
    labels = ["chat_header", "header"] + [t["id"] for t in spec["tools"]]
    labels += ["footer", "chat_footer", "boundary"]
    labels = [b for b in labels if any(b in r["blocks"] for r in rows)]
    fig, axes = plt.subplots(
        1, 2, figsize=(14, max(4, len(selected) * 0.4)), constrained_layout=True
    )
    for axis, kind in zip(axes, ("k", "v"), strict=True):
        values = np.array(
            [
                [
                    r["blocks"].get(b, {}).get(kind, {}).get("relative_l2")
                    for b in labels
                ]
                for r in selected
            ],
            dtype=float,
        )
        image = axis.imshow(
            np.ma.masked_invalid(values),
            aspect="auto",
            interpolation="nearest",
            vmin=0,
            cmap="viridis",
        )
        axis.set_xticks(range(len(labels)), labels, rotation=65, ha="right", fontsize=8)
        row_labels = [
            f"-{spec['tools'][cases[r['mask']]['mask']['removed'][0]]['id']}"
            if loo
            else r["mask"]
            for r in selected
        ]
        axis.set_yticks(range(len(selected)), row_labels, fontsize=8)
        axis.set_title(f"{method}: {kind.upper()} block relative L2")
        axis.set_ylabel("Single-tool removal" if loo else "Measured masks (up to 20)")
        axis.set_facecolor("#dddddd")
        fig.colorbar(image, ax=axis)
    fig.savefig(out / "block_impact.png", dpi=160)
    plt.close(fig)
    # Export one detailed view for sharing. Interactive HTML has all selected views.
    view = next(
        (d for d in details if d["method"] == "rope"), details[0] if details else None
    )
    if view:
        err, ref = np.array(view["error_sq"]), np.array(view["reference_sq"])
        ratios = np.sqrt(
            np.divide(err, ref, out=np.full_like(err, np.nan), where=ref > 0)
        )
        fig, axes = plt.subplots(2, 1, figsize=(14, 7), constrained_layout=True)
        for i, kind in enumerate(("K", "V")):
            im = axes[i].imshow(
                ratios[:, i], aspect="auto", interpolation="nearest", vmin=0
            )
            axes[i].set(
                xlabel="Subset token position",
                ylabel="Layer (zero based)",
                title=f"{view['mask']} / {view['method']} / {kind} relative L2",
            )
            for j, token in enumerate(view["tokens"]):
                if j == 0 or token["block"] != view["tokens"][j - 1]["block"]:
                    axes[i].axvline(j - 0.5, color="white", linewidth=0.6)
                    axes[i].text(
                        j,
                        0,
                        token["block"],
                        rotation=90,
                        fontsize=6,
                        color="white",
                        va="top",
                    )
            fig.colorbar(im, ax=axes[i])
        fig.savefig(out / "tokens.png", dpi=160)
        plt.close(fig)
