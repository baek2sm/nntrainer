"""Reproducible subset-prefix experiments; no model imports at plan/report time."""

SCHEMA_VERSION = 1
