# Sparse subset-prefix benchmark

원래 순서를 유지하면서 도구 블록을 제거한 요청에서 KV 재사용 방법을 비교하는
벤치마크다. 기존 `kv_loo_*` / `tool_*` 스크립트와 결과는 변경하지 않는다.
이 벤치의 결과는 자체 manifest, 모델, 실행 경로 안에서 비교한다.

현재 실행기는 **비양자화 Qwen3 + Hugging Face eager reference**다. 실제 QuickKV
커넥터의 로드/저장 성능이나 vLLM TTFT를 측정하는 실행기가 아니다. 먼저 수치와
평가 계약을 검증하고, 이후 serving backend에도 같은 케이스와 결과 스키마를
적용하기 위한 기준 구현이다. AWQ, 다른 모델 구조, scaled/dynamic RoPE는
검증 없이 수용하지 않는다.

## 실행

저장소 루트에서 실행한다. 기존 환경에 의존성을 설치하려면 `pip install -e '.[bench,dev]'`.
실행 모델은 로컬 Hugging Face cache 또는 로컬 경로에 있어야 하며 자동 다운로드하지 않는다.
현재 검증 환경은 Python 3.10, torch 2.11, transformers 5.12다. 실제 실행 버전은
각 run에 기록된다. `plan`은 모델이나 torch 없이 실행할 수 있다.

```bash
python3 -m benchmarks.sparse_bench plan \
  --out /tmp/sparse-bench/manifest.json

# 작은 실모델 검증: 전체 제거, 흩어진 5개 유지, 1개 제거, 전체 유지.
# query-limit/repeats=1은 파이프라인 확인용이며 품질/지연 결론을 내리지 않는다.
python3 -m benchmarks.sparse_bench run \
  --manifest /tmp/sparse-bench/manifest.json \
  --out /tmp/sparse-bench/smoke \
  --masks m000,m155,m3fe,m3ff \
  --methods splice rope random gap oracle_diff oracle_copy early_key \
  --budgets 0 .05 .15 .30 1 --repeats 1 \
  --include-absent --query-limit 1 --max-tokens 16

python3 -m benchmarks.sparse_bench report \
  --run /tmp/sparse-bench/smoke --out /tmp/sparse-bench/report \
  --detail-masks m155,m3fe,m000,m3ff --export-tokens
```

`report/index.html`을 브라우저에서 직접 열면 된다. 인터넷이나 HTTP 서버가 필요 없다.
원본 run과 report는 다른 디렉터리에 둔다. manifest/run/report는 새 경로를 사용해
이전 실행의 파일이 섞이지 않게 한다.
실패한 run은 `status=failed`로 보존하고 리포트에서 거부한다.

## 고정된 워크로드

기본 [`device_tools.json`](device_tools.json)은 10개 도구, 도구별 쿼리 3개,
공통 지시문을 정의한다. 모델의 chat template으로 system turn을 렌더링하고,
쿼리는 user turn으로 넣는다. Qwen3 thinking은 명시적으로 끈다. 캐시 대상은
완성된 system turn이며 user/assistant turn과 응답은 캐시하지 않는다.
평문 프롬프트는 custom spec의 `prompt_format: plain`으로 사용할 수 있다.

- 순서 유지 subset은 `2^10=1,024`개. 빈 집합과 전체 유지도 무결성/경계 케이스다.
- 마스크의 bit `i=1`은 도구 `i` 유지다. `m155`는 0,2,4,6,8번 도구 유지다.
- 5개 유지만 평가하면 `C(10,5)=252`개다. 제거 쌍은 45개다.
- 정답 도구가 남은 쿼리 조합은 기본 spec에서 15,360개다.
  `--include-absent`이면 제거된 도구에 대한 쿼리도 포함해 총 30,720개다.
  제거된 도구의 정답은 항상 `no_tool`이며, present/absent 정확도를 분리한다.
- 같은 마스크에서 모든 쿼리를 평가하고, 같은 쿼리를 여러 마스크에서 평가한다.
  `--query-limit`은 목록 앞부분만 택하므로 smoke 용도로만 쓴다.
- manifest는 spec, 모든 마스크, 고정 seed, 마스크별 train/dev/test split과 SHA256을
  담는다. split은 마스크 기준이며 쿼리를 바꿔도 같은 split에 남는다.
  학습한 마스크/체크레이어/예산은 train/dev에서 고르고 test는 최종 평가에 쓴다.
- `--query-families wording-0 wording-1` 등으로 쿼리 변형도 분리할 수 있다.
  이는 같은 10개 태스크의 표현 변형이므로 새로운 태스크 일반화 증거는 아니다.

custom spec은 기본 JSON과 같은 필드를 사용한다. `plan --spec ...`으로 새 manifest를
만든다. 다른 도구 순서·설명 길이·유사 도구 구성·다른 템플릿은 각각 별도 manifest다.
마스크 전수 평가가 다른 템플릿이나 모델에 대한 일반화까지 입증하지 않는다.

## 토큰 정합성과 참조

항상 **전체 자연 문자열을 한 번에 tokenize**한다. 블록을 각각 tokenize한 ID를
연결하지 않는다. fast tokenizer의 문자 offset으로 토큰을 블록에 연결하고,
`block ID + 블록 내부 문자 범위 + token ID + 중복 offset 내 출현 순서`가 일치할
때만 superset 위치를 매핑한다. Unicode byte token의 중복 offset도 처리한다.

블록 경계에 걸치거나 삭제 후 token ID가 바뀐 토큰은 `source_position=-1`이다.
이들은 모든 sparse arm에서 실제 레이어별 재계산으로 복구하는 **필수 비용**이며,
선택 예산과 따로 기록한다. 재계산된 토큰은 mixed KV에 causal attention을 수행하고,
각 레이어에서 자신의 새 K/V를 삽입한다. GT 값을 암묵적으로 복사하지 않는다.

참조 KV는 쿼리 없이 subset system prefix 전체를 cold prefill해서 얻는다.
쿼리를 붙일 때는 실제 request와 prefix token IDs의 최장 공통 앞부분까지만 재사용한다.
경계에서 달라진 토큰은 query suffix에서 다시 계산한다. full-request cold logits와도
대조한다. BOS 등의 special token을 암묵적으로 중복 삽입하지 않는다.

## 비교 방법과 예산

`cold`와 `exact`는 항상 포함한다. 모든 선택기는 header/footer/chat wrapper를 포함한
동일한 **재사용 가능 prefix 토큰 전체**를 후보로 사용한다.

| 이름 | 처리 | GT 사용 |
|---|---|---|
| cold | subset 전체 prefill | 참조 |
| exact | 동일한 연속 앞부분만 재사용, 나머지 전체 재계산 | 없음 |
| splice | 위치 보정 없이 이어붙임 + 경계 복구 | 없음 |
| rope | 기본 RoPE의 위치 delta로 K 재회전 + 경계 복구 | 없음 |
| random | rope 위에 고정 난수 순서로 선택 후 실제 재계산 | 없음 |
| gap | 삭제/경계 직후에 가까운 토큰 순으로 선택 후 실제 재계산 | 없음 |
| early_key | 초기 레이어 전체 계산 후 체크레이어의 fresh/cached K 차이로 전역 선택 | 없음 |
| oracle_diff | K/V 차이 제곱합으로 전역 선택 후 실제 재계산 | 선택에 사용 |
| oracle_copy | 같은 diff 선택 위치를 cold KV로 복사 | 선택·교체에 사용 |

`--budgets .05 .15 ...`는 **재사용 가능 토큰 수의 비율**이며 `ceil(budget * candidates)`를
선택한다. 동점은 토큰 위치 순서로 처리한다. 필수 경계 토큰은 예산 외에 추가한다.
random은 같은 마스크/seed에서 예산별 선택이 nested되며, `--selection-seed`를 바꿔도
manifest split은 바뀌지 않는다. random 비교에는 여러 seed를 사용한다.

`early_key`는 기본 체크레이어 1(0 기반) 이전의 모든 prefix 토큰을 계산하고,
레이어 1에서 추가 K projection으로 점수를 얻는다. 레이어 1부터는 선택 토큰과
필수 경계 토큰만 계산한다. `early_key@0`도 초기 전체 계산 비용이 있다.
논문의 전체 CacheBlend 런타임이나 단계별 filtering을 재현한 구현은 아니다.
선택 토큰 수가 같아도 계산량/시간이 같지 않다. `oracle_copy`는 진단용 비교이지
실제 재계산의 수학적 출력 품질 상한이라고 가정하지 않는다.

## 고정 구간 KV 로드 생략 + 재계산

`gap_chunk16`, `gap_chunk32`, `gap_chunk64`는 비율 예산을 사용하지 않는다.
요청의 도구 제외 목록으로 실제 삭제 run 뒤의 첫 유지 토큰을 찾고,
각 시작점에서 subset 토큰 16/32/64개를 선택한다. 도구 경계를 넘어갈 수 있으며
prefix 끝에서 자른다. 겹치는 창은 합치고, 매핑 불가능한 토큰화 경계는 별도 복구한다.
삭제가 없는 요청에는 추가 창을 만들지 않는다.

선택 위치는 **superset K/V를 gather하지 않는다**. 나머지만 복사하고 K를 재회전한다.
선택 토큰은 embedding부터 모든 레이어를 통과하고, 각 레이어에서 앞쪽의 혼합 KV를
참조한다. 여러 창은 현재 reference backend에서 레이어별로 함께 계산한다.
청크를 순차 처리하는 serving pipeline이나 다음 청크의 비동기 로드는 구현하지 않았다.
오래된 앞쪽 KV를 참조하는 창에는 오차가 남을 수 있고, 창 뒤의 로드 토큰도
자동으로 보정되지는 않는다.

`metrics.json`에는 실제 선택 위치, 병합한 반열림 구간 `[start,end)`, 로드 토큰 수,
원본 KV의 논리적 읽기 바이트와 생략 바이트를 기록한다. 바이트 수는 해당 실행의
KV dtype/shape 기준이며, 압축 파일 크기나 실제 저장장치 전송량이 아니다.
시간은 **resident CPU/GPU tensor 조립과 재계산**에 한정한다. I/O 전송·중첩에 따른
속도 이득은 이 실험으로 주장하지 않는다.

리포트는 기존 도구 제외 K/V 행렬과 생성 토큰 보존 표에 세 방법을 추가하고,
선택 방법 아래에 실제 로드/재계산 구간을 표시한다. 15% 방법과 선택 토큰 수가
다르므로, 품질 향상만으로 같은 계산량에서의 우위를 주장할 수 없다.

```bash
python -m benchmarks.sparse_bench run \
  --manifest benchmarks/results/sparse_bench_json_trace_v1/manifest.json \
  --out benchmarks/results/sparse_bench_json_trace_v1/chunk_repair_v1 \
  --methods rope gap cacheblend_superset gap_chunk16 gap_chunk32 gap_chunk64 \
  --budgets .15 --masks m3af,m0cf,m2aa,m096,m0c4,m190,m006,m005 \
  --repeats 3 --threads 4 --include-absent --query-families wording-2 \
  --query-limit 1 --max-tokens 96 --min-reference-tokens 32 --heads
```

## 초기 레이어 전체 재계산 + 이후 KV 로드

`early_layers1`, `early_layers2`, `early_layers4`, `early_layers8`은 subset의 모든 토큰을
embedding부터 처음 L개 레이어까지 계산한다. 이 레이어들의 원본 KV는 읽지 않는다.
L 이후의 유효하게 매핑된 KV는 superset에서 로드하고 K를 요청 위치로 재회전한다.
**앞쪽 계산이 뒤쪽의 로드된 KV를 갱신하지는 않는다.** hidden state를 추가 저장하지 않는다.

재사용 불가능한 토큰화 경계 토큰만 L 이후에도 hidden state를 이어서 계산한다.
이 예외 비용은 `late_boundary_repair`와 `recomputed_token_layers`에 포함한다.
선택 신호를 얻기 위한 전체 K 비교/projection은 없으며, cold 값은 무결성 검사와
평가에만 사용한다. 실제 실행마다 초기 L개 레이어의 KV가 cold와 일치하는지 검사한다.

새 결과에는 초기 레이어 수, 실제 계산 토큰×레이어 수, 로드 토큰×레이어 수,
논리적 KV 읽기/생략 바이트를 기록한다. 재계산과 로드의 두 범위는 전체 subset의
토큰×레이어 영역을 정확히 분할한다. 리포트는 레이어별 처리 그림과 토큰×레이어
기준 비중을 표시한다. 토큰 15%를 모든 레이어에서 계산하는 방법과 구분한다.
조립 시간은 resident tensor reference이며 저장장치 I/O나 비동기 중첩 측정은 아니다.

`layer_error_energy.csv`는 RoPE 기준의 레이어별 잔여 오차 제곱합과 누적 비중을
내보낸다. 부분 마스크의 모든 prefix 토큰을 에너지로 합산하며, 전체 유지/전체 삭제
경계 조건은 제외한다. 이 비중은 상대 L2 감소율과 다른 지표다.

## 무결성 검사와 수치 기준선

다음 검사를 통과한 케이스만 완료 표시한다. 하나라도 실패하면 run 전체가 실패한다.

1. superset / subset의 동일 형태 cold 반복 KV.
2. 모든 prefix 토큰을 mixed-cache 재계산 경로에 넣었을 때 cold KV 재구성.
3. exact 조립 경로와 **HF 기본 prefix-cache 이어계산 경로**의 일치.
4. cold 생성의 반복 token IDs 일치.
5. prefix+suffix cold 계산과 full-request cold 계산의 첫 응답 logits 일치.

exact와 full cold는 수학적으로 같은 문맥이더라도 matmul/attention 계산 형태 차이로
비트 단위 결과가 다를 수 있다. `native_exact_vs_cold_numerical_floor`와 exact arm의
KV/출력 차이를 별도로 보존한다. 실제 FP32 Qwen3-0.6B 검증에서 exact와 native
continuation은 완전히 같았고, native continuation과 full cold 사이에는 작은
수치 차이가 있었다. 이 차이를 sparse 문맥 손실과 섞지 않는다.

기본 tolerance는 FP32 기준 `KV atol=1e-5`, `logits atol=1e-4`, `rtol=1e-4`다.
저정밀 backend를 쓸 때는 먼저 기준 경로를 검증해 tolerance를 정해야 한다.
실패를 없애기 위해 근거 없이 tolerance를 높이지 않는다. 임계값은 run에 남는다.

## 저장 형식과 집계

```text
run/
  manifest.json                 # 불변 workload + checksum
  run.json                      # config, backend, 버전/모델/토크나이저/코드, 상태
  source_tokens.json            # superset token IDs·블록·문자 범위
  source_kv.npz                 # --save-kv reference/all일 때만
  cases/<mask>/
    case.json                   # subset 텍스트·토큰·source mapping·수치 기준선
    gates.json                  # 실제 무결성 검사 결과
    reference_kv.npz            # --save-kv reference/all일 때만
    <method>/metrics.json       # 전체/블록 통계, 선택 위치, 비용 원시 샘플
    <method>/stats.npz           # 레이어×K/V×토큰 충분통계
    <method>/kv.npz              # --save-kv all일 때만
    quality.json                # 쿼리별 생성·정답·teacher-forced 분포 차이
    complete.json               # 완료 표시 + 케이스 파일 checksum
```

`stats.npz`의 `error_sq/reference_sq/max_abs/dot/arm_sq`는 `[layer, 2, token]`이다.
`--heads`를 쓰면 `[layer, 2, token, kv_head]` 단위 squared energy도 저장한다.
K/V 축은 0=K, 1=V다. 모든 토큰은 `case.json`의 동일 position으로 연결된다.
전체 KV 벡터를 저장하는 옵션은 `[layer, 2, token, kv_head, head_dim]` FP32이며
원래 FP16/BF16 값을 FP32로 옮기는 경우 그 값은 보존된다. 저장량이 매우 크므로
기본값은 충분통계만 저장한다. `--no-token-level`은 전체/블록 요약만 남긴다.

상대 L2는 `sqrt(sum(error_sq) / sum(reference_sq))`다. 도구별/레이어별 비율을
무작정 평균한 값과 다르다. summary는 pooled 비율과 mask별 macro 평균, p95,
최악값을 구분하고 제거 개수별/split별 결과도 제공한다. 참조 에너지가 0인 비율은
`null`이며 0이나 epsilon으로 숨기지 않는다. 표시 대상의 토큰 하나도
전체 레이어의 오차 에너지를 합산한 값과 특정 레이어의 값을 구분한다.

정확도는 출력의 앞뒤 공백만 제거한 후 **사용 가능한 tool ID 또는 no_tool과
완전히 일치**해야 정답이다. 이름의 부분 문자열 포함 여부를 사용하지 않는다.
정답률, 형식 준수율, cold 정답→오답 / 오답→정답 전환, 전체 token ID 일치를 분리한다.
출력 분포 비교는 cold 응답 히스토리를 동일하게 teacher-force한 **전체 vocabulary**의
TVD/KL/argmax다. top-20 재정규화 TVD나 서로 발산한 히스토리를 비교하지 않는다.

품질의 paired accuracy 차이는 mask 단위 cluster bootstrap CI를 제공한다.
토큰/레이어를 독립 표본으로 세지 않으며, CI는 고정 템플릿·고정 쿼리 하의 mask
재표집에 한정된다. 표본이 mask 하나뿐이면 CI를 내지 않는다.

## 리포트와 토큰 시각화

기본 리포트는 어두운 테마의 **도구별 KV 오차 → 토큰별 KV 오차**로 구성한다.
선택 규칙·선택 비율·캐시 생성 문맥을 하나의 KV 조립 케이스로 묶으며, 두 화면의
선택을 동기화한다. 실험 구성과 원본 근거는 접을 수 있다.

여러 실행도 한 장으로 통합할 수 있다. manifest, 모델·tokenizer·dtype·backend 관련
조건이 맞는 실행만 받으며, 각각의 표본·분모와 품질 측정 범위를 유지한다.
중복 마스크는 상단 고유 subset 수에서 한 번만 센다. 서로 다른 실행의 평균을
합치지 않는다. KV-only 실행의 미사용 생성 길이는 품질 비교 조건에 포함하지 않는다.

```bash
python3 -m benchmarks.sparse_bench report \
  --run /tmp/sparse-bench/loo \
  --also-run /tmp/sparse-bench/correction \
  --out /tmp/sparse-bench/integrated-report \
  --detail-limit 14 --detail-methods all
```

도구별 행렬의 셀을 누르면 해당 제외 케이스와 도구의 토큰 분석이 연결된다.
조립 케이스에 측정이 없는 조건은 미측정으로 표시한다. 토큰 보기에서는 도구 하나를
확대해 실제 token piece와 위치를 확인할 수 있다. 각 실행의 CSV는 통합 출력의
`data/run-*/`에 있으며, 원시 run은 수정하지 않는다.

- `index.html`: 외부 의존성 없는 리포트. mask/method 선택, 도구별 오차 표,
  layer×token heatmap, 정확한 token piece/ID/source·subset 위치를 보여주는 tooltip,
  오차가 큰 토큰 순위, 선택/경계 복구 표시.
- heatmap은 K/V별 relative L2, absolute L2, 전체 오차 에너지 중 비율을 전환한다.
  색 범위는 현재 view 기준이며 비교할 때 표시된 최대값도 확인한다.
- `summary.png`: 제거 도구 수별 K/V pooled rel-L2.
- `block_impact.png`: 한 도구씩 제거했을 때 retained 도구별 K/V 차이 행렬.
  LOO 마스크가 없으면 측정된 마스크 최대 20개를 명시해서 표시한다. 제거된 도구는
  회색으로 표시하며 0 오차와 구별한다.
- `tokens.png`: 첫 번째 선택 detail mask의 rope(없으면 첫 방법) layer×token 그림.
- `masks.csv`, `blocks.csv`: 모든 측정 마스크의 전체/도구별 결과.
- `quality.csv`, `kv_quality.csv`: 쿼리 결과, 같은 mask/method의 KV와 품질을 연결한 결과.
- `--export-tokens`: 저장된 모든 layer/token의 `tokens.csv`를 스트리밍 출력한다.

HTML에 모든 토큰 배열을 넣으면 파일이 커지므로 기본은 rope K 오차가 큰 마스크
8개에 해당하는 주 비교 조립 케이스를 embed한다. 이는 표시 선택이며 원본 CSV를
제한하지 않는다. `--detail-methods all`이 기본값이고, `--detail-limit 14` 등으로
표시할 마스크 수를 늘릴 수 있다. 무손실 대조군·경계 검증의 토큰 배열은 주 화면에서 제외한다.
`--detail-masks m155,m3fe`로 다른 마스크와 순서를 선택할 수 있다.
held-out test의 시각화를 보고 선택기를 조정하면 test에 누출되는 점에 유의한다.

## 실행 규모와 비용

```bash
# 전체 subset KV 구조부터 확인. 쿼리 평가 없이 전수 조사.
python3 -m benchmarks.sparse_bench run \
  --manifest /tmp/sparse-bench/manifest.json --out /tmp/sparse-bench/kv-all \
  --methods splice rope --kv-only --repeats 3

# 고정 test masks × 보류한 표현 변형. 별도 새 run으로 실행.
python3 -m benchmarks.sparse_bench run \
  --manifest /tmp/sparse-bench/manifest.json --out /tmp/sparse-bench/test-quality \
  --split test --query-families wording-2 --methods rope gap early_key \
  --budgets 0 .05 .15 .30 --repeats 5 --device cuda --dtype float32
```

`--shards 4 --shard-index 0` 등으로 mask를 나눌 수 있다. 각 shard는 별도 디렉터리에
저장하고 별도 리포트를 만든다. 현재 자동 shard 병합/중단 재개는 지원하지 않는다.
전체 마스크의 cold KV를 GPU에 쌓지 않고 마스크별로 진행한다. 쿼리 평가가 켜져
있으면 현재 마스크의 arm KV들은 쿼리 비교를 위해 유지하므로 방법/예산 수에 따라
메모리가 늘어난다. 많은 방법은 같은 manifest를 사용하는 여러 run으로 나눈다.

시간은 모델 로딩·GT 생성·통계/시각화·쿼리 평가를 제외한 **각 방법의 조립+선택+
필수 복구+부분 재계산**을 warmup 후 반복해서 잰 값이다. CUDA는 동기화한다.
원시 시간 샘플, median, p95를 저장한다. GPU allocator peak와 기존 resident
메모리도 저장하지만 source/cold/이전 arm이 상주하므로 격리된 serving peak가 아니다.
oracle의 GT 준비 비용은 시간에 포함되지 않아 practical 방법과 지연 순위를 매기면 안 된다.

현재 생성 비용과 실제 connector TTFT는 보고하지 않는다. serving 비용을 검증하려면
같은 manifest를 QuickKV 실행 경로에 연결하고 backend 무결성 검사를 다시 통과시켜야 한다.

## 검증과 확장

```bash
python3 -m pytest tests/benchmarks/test_sparse_bench.py -q
ruff check benchmarks/sparse_bench tests/benchmarks/test_sparse_bench.py
```

테스트는 다운로드 없이 작은 실제 Qwen3 구조를 무작위 초기화해 3개 도구의
모든 8개 마스크, 모든 정책의 0/부분/전체 예산, 실제 재계산과 causal 성질,
전체 어휘 분포 지표, artifact/리포트 생성과 checksum 변조 검출을 검증한다.
이 테스트 모델의 정확도는 연구 결과로 사용하지 않는다.

새 선택기는 `backend.select_positions` 또는 별도 backend 메서드로 추가하고,
`runner.construct`에서 호출한다. practical 경로는 cold KV를 받지 않도록 유지한다.
새 모델/커널 backend는 prefill, exact, splice, recompute, generate, teacher_logits와
수치 기준선을 먼저 검증한다. 비교할 run은 manifest hash, 모델 revision, tokenizer hash,
dtype/backend, 후보 범위, 예산, 생성 설정, 마스크/쿼리 coverage가 같은지 확인한다.
독립 블록 저장, gradient 선택, learned residual 등은 이 계약 위에서 별도 실험으로
추가하며, 과거 다른 조건의 숫자를 같은 표에 자동 합치지 않는다.

## CacheBlend 캐시 생성 문맥 비교

현재 리포트의 조립 케이스는 위치 보정 없는 splice, RoPE만 적용, 삭제 직후 15%
재계산, CacheBlend 독립 캐시 15%, CacheBlend 순차 캐시 15%다. 별도의
부분 재계산 섹션 없이 같은 도구별·토큰별 오차 화면에서 선택한다.

- `cacheblend_independent`: 자연 토큰화한 원본을 H / 도구별 블록 / F로 분할해
  각 블록을 위치 0부터 독립 prefill. K를 원본 위치로 정규화한 후 요청 위치로 조립.
- `cacheblend_superset`: superset 전체를 causal prefill한 KV에서 필요한 블록을 조립.
- 두 조건은 같은 single-check 선택기, 같은 checkpoint layer(기본 1), 같은 전역
  후보, 같은 `ceil(0.15 * 재사용 가능 토큰 수)`를 사용한다. GT 없이 선택하며
  초기 레이어 전체 계산 후 선택 토큰을 mixed KV에 attend시키며 재계산한다.
- H/F도 선택 후보이며, 경계 복구 토큰은 별도다.
- CacheBlend의 단일 체크 선택 원리를 사용한 HF 기준 구현이다. 논문의 전체
  runtime/filtering 및 serving 성능을 재현했다는 의미는 아니다.

```bash
python3 -m benchmarks.sparse_bench run \
  --manifest /tmp/sparse-bench/manifest.json --out /tmp/sparse-bench/cacheblend \
  --methods splice rope gap cacheblend_independent cacheblend_superset \
  --budgets .15 --repeats 3
```

보고서 HTML은 어두운 테마를 사용한다. 미측정 값은 `—`, 제외된 도구는 `제외`로
구분한다. 각 조립 케이스는 측정된 subset 수를 표시하고 두 오차 화면에 동기화된다.
화면에 내장한 토큰 충분통계는 용량을 줄이기 위해 유효숫자 6자리로 표시하며
원본 NPZ/CSV 정밀도는 유지한다.

리포트의 두 오차 패널 우측 상단에는 **선택한 subset과 KV 조립 케이스의 latency**를
표시한다. 원본 KV 복사 대비 추가 시간·배수도 같은 subset에서 비교한다. 값은 저장된
`construction_median_ms`이며, 실제 측정 장치와 반복 수를 함께 표시한다.
캐시 조립·RoPE 보정·경계 복구·선택/재계산을 포함하며 사전 캐시 생성, GT 생성,
응답 생성과 serving TTFT는 포함하지 않는다.

## 생성 토큰 보존 평가

주 평가 대상은 같은 subset을 전체 재계산한 cold의 **생성 token ID 보존**이다.
도구 정답률은 별도 보조 지표다. cold가 도구를 잘못 고르는 경우에도 보존 지표는
cold 출력과 비교하며, cold 자체의 정답률을 함께 공개한다.

- 전체 일치: 관측한 출력 token ID와 길이가 모두 동일한 요청 비율.
- 공통 prefix: 첫 발산 이전 토큰 수와 cold 길이 대비 비율. 요청별 평균을 보고한다.
- 위치별 일치: 같은 위치에서 일치한 token ID 수 / 두 출력 중 긴 길이.
  길이 차이도 불일치로 센다. 발산 후 우연한 재일치가 포함되므로 prefix와 함께 본다.
- 길이별 보존: 처음 16/32/64/96토큰이 모두 유지된 요청 수 / cold가 그 길이
  이상 생성한 요청 수. 길이가 부족한 요청을 성공으로 세지 않는다.
- Teacher-forced 다음 토큰 일치: 동일한 cold 히스토리에서 argmax를 비교한다.
  자유 생성의 누적 발산과, 같은 문맥에서의 분포 변화를 구분하기 위한 진단이다.

짧은 도구명 응답과 긴 JSON 응답은 별도 워크로드다. 생성 상한에서 잘린 출력의
전체 일치는 그 상한 내 관측 토큰열에만 해당한다. `--min-reference-tokens 32`로
긴 응답 실험이 실제로 짧은 출력만 측정하는 것을 방지한다.

```bash
python3 -m benchmarks.sparse_bench.dashboard --out /tmp/sparse-dashboard \
  --report '긴 응답=benchmarks/results/sparse_bench_json_trace_v1/token_report' \
  --report '도구명 응답=benchmarks/results/sparse_bench_chat_v1/gradient_validation_final'
```

대시보드는 각 report의 manifest/마스크/쿼리를 합산하지 않고 워크로드별로 전환한다.
새 리포트는 원시 run의 완료 표시와 checksum을 검증한 `report` 명령으로 먼저 생성한다.

## Superset 전용 gradient 실험

`saliency.py`는 superset KV와 superset 다음 토큰 NLL만으로 중요도를 계산한다.
subset의 cold KV, 쿼리, cold 응답, 발산 위치는 선택에 입력하지 않는다.
전체 NLL, 도구별 균등 NLL, footer NLL의 gradient norm 계열과 CacheBlend와의
가중 결합을 비교한다. offline backward 시간은 템플릿당 비용으로 별도 기록한다.
실제 온라인 선택/재계산은 동일한 전역 15% 예산이다.

`gap`은 실제로 제외한 도구 구간의 끝을 기준으로 가장 가까운 유지 토큰을 고른다.
토큰화 seam은 추가 삭제 지점으로 간주하지 않는다(`actual_removed_tool_distance_v2`).
예산은 도구마다 15%가 아니라 H/F 포함 재사용 후보 전체의 15%다. 따라서 직후 도구가
짧으면 전체가 선택될 수 있다. CacheBlend도 선택 수는 같지만 초기 레이어 전체 prefix
계산과 체크레이어 K projection이 추가되므로 계산량은 다르다.

현재 긴 JSON 응답 파일럿은 Qwen3-0.6B / CPU FP32 / 8 subset / 요청 8건이며,
cold 출력은 63–96토큰이다. 순차 CacheBlend 15%는 전체 일치 1/8, 평균 공통 prefix
49.90%; footer gradient 15%는 2/8, 48.42%다. 지표별 우열이 다르고 표본이 작아
gradient의 보존력 개선이 확인된 상태는 아니다. cold 도구 정답도 4/8이므로
이 워크로드의 의미 정확도와 cold 토큰 보존은 구분해야 한다.
