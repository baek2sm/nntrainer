"""Group report views without pooling different workloads or manifests.

Repeated labels combine compatible runs in one workload. The first label is
the default view; additional workloads remain selectable.

python -m benchmarks.sparse_bench.dashboard --out DIR --report 'Label=REPORT_DIR'
"""

import argparse
import json
from pathlib import Path


def build(out, reports):
    out = Path(out)
    if out.exists() and any(out.iterdir()):
        raise ValueError("dashboard output must be empty")
    groups = []
    for i, (label, directory) in enumerate(reports):
        directory = Path(directory).resolve()
        view = json.loads((directory / "view.json").read_text())
        if not view.get("quality"):
            raise ValueError(f"report has no generation measurements: {directory}")
        ident = f"workload-{i}"
        view["id"] = ident
        view["downloads"] = f"workloads/{ident}/"
        group = next((g for g in groups if g["label"] == label), None)
        if group is None:
            groups.append({"id": ident, "label": label, "experiments": [view]})
        else:
            first = group["experiments"][0]
            config_keys = (
                "model",
                "revision",
                "dtype",
                "device",
                "check_layer",
                "selection_seed",
                "max_tokens",
            )
            if first["summary"]["manifest_sha256"] != view["summary"][
                "manifest_sha256"
            ] or any(
                first["summary"]["run_config"].get(k)
                != view["summary"]["run_config"].get(k)
                for k in config_keys
            ):
                raise ValueError(
                    "grouped reports must share manifest and run configuration"
                )
            group["experiments"].append(view)
    if not groups:
        raise ValueError("at least one report is required")
    out.mkdir(parents=True, exist_ok=True)
    (out / "workloads").mkdir()
    for i, (_, directory) in enumerate(reports):
        (out / "workloads" / f"workload-{i}").symlink_to(
            Path(directory).resolve(), target_is_directory=True
        )
    payload = json.dumps({"groups": groups}, ensure_ascii=False, separators=(",", ":"))
    template = Path(__file__).with_name("report.html").read_text()
    (out / "index.html").write_text(
        template.replace("__TITLE__", "Sparse Prefix KV").replace(
            "__PAYLOAD__", payload.replace("<", "\\u003c")
        )
    )
    (out / "sources.json").write_text(
        json.dumps(
            [
                {"label": label, "report": str(Path(path).resolve())}
                for label, path in reports
            ],
            ensure_ascii=False,
            indent=2,
        )
        + "\n"
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True)
    parser.add_argument("--report", action="append", required=True, metavar="LABEL=DIR")
    args = parser.parse_args()
    reports = []
    for entry in args.report:
        if "=" not in entry:
            parser.error("--report requires LABEL=DIR")
        label, directory = entry.split("=", 1)
        if not label or not directory:
            parser.error("--report requires nonempty LABEL and DIR")
        reports.append((label, directory))
    build(args.out, reports)


if __name__ == "__main__":
    main()
