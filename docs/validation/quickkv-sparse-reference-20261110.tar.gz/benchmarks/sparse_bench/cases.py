"""Immutable workloads and character-to-token alignment for natural prompts."""

import hashlib
import json
from collections import Counter
from pathlib import Path

from . import SCHEMA_VERSION


def digest(value):
    encoded = json.dumps(value, sort_keys=True, ensure_ascii=False).encode()
    return hashlib.sha256(encoded).hexdigest()


def validate_spec(spec):
    tools = [t["id"] for t in spec["tools"]]
    if not tools or len(tools) != len(set(tools)):
        raise ValueError("tool IDs must be nonempty and unique")
    if set(tools) & {"header", "footer", "boundary", "chat_header", "chat_footer"}:
        raise ValueError("tool IDs collide with reserved block names")
    if any(
        not isinstance(t, str) or not t or any(c.isspace() for c in t) for t in tools
    ):
        raise ValueError("tool IDs must be nonempty single labels without whitespace")
    if spec["no_tool"] in tools or any(not t["text"] for t in spec["tools"]):
        raise ValueError("invalid tool text or no_tool label")
    queries = spec["queries"]
    if len({q["id"] for q in queries}) != len(queries):
        raise ValueError("query IDs must be unique")
    if any(q["target"] not in tools for q in queries):
        raise ValueError("unknown query target")
    if "{query}" not in spec["query_format"]:
        raise ValueError("query_format must contain {query}")
    spec["query_format"].format(query="test")
    if spec.get("prompt_format", "plain") not in ("plain", "chat"):
        raise ValueError("prompt_format must be plain or chat")
    if spec.get("output_format", "label") not in (
        "label",
        "tool_first_line",
        "tool_json",
    ):
        raise ValueError("unknown output_format")


def make_manifest(spec, seed=0):
    validate_spec(spec)
    n = len(spec["tools"])
    if n > 16:
        raise ValueError("exhaustive manifests are limited to 16 tools")
    masks = []
    for bits in range(1 << n):
        kept = [i for i in range(n) if bits & (1 << i)]
        # A mask belongs to one split regardless of its queries or method.
        bucket = int(digest([seed, bits])[:8], 16) % 10
        masks.append(
            {
                "id": f"m{bits:0{(n + 3) // 4}x}",
                "bits": bits,
                "kept": kept,
                "removed": [i for i in range(n) if i not in kept],
                "split": "train" if bucket < 6 else "dev" if bucket < 8 else "test",
            }
        )
    manifest = {
        "schema_version": SCHEMA_VERSION,
        "seed": seed,
        "scope": "order-preserving subsets of one fixed superset",
        "spec": spec,
        "masks": masks,
    }
    manifest["sha256"] = digest(manifest)
    return manifest


def read_manifest(path):
    manifest = json.loads(Path(path).read_text())
    checksum = manifest.pop("sha256")
    if digest(manifest) != checksum or manifest["schema_version"] != SCHEMA_VERSION:
        raise ValueError("manifest checksum or schema mismatch")
    expected = make_manifest(manifest["spec"], manifest["seed"])
    manifest["sha256"] = checksum
    if manifest != expected:
        raise ValueError("manifest does not match the canonical exhaustive workload")
    return manifest


def render(spec, kept):
    parts = [("header", spec["header"])]
    parts += [(spec["tools"][i]["id"], spec["tools"][i]["text"]) for i in kept]
    parts += [("footer", spec["footer"])]
    text, spans = "", []
    for name, part in parts:
        spans.append({"block": name, "start": len(text), "end": len(text) + len(part)})
        text += part
    return text, spans


def render_prefix(spec, kept, tokenizer):
    content, spans = render(spec, kept)
    if spec.get("prompt_format", "plain") == "plain":
        return content, spans
    if not tokenizer.chat_template:
        raise ValueError("chat workload requires a tokenizer chat template")
    text = tokenizer.apply_chat_template(
        [{"role": "system", "content": content}],
        tokenize=False,
        add_generation_prompt=False,
        **spec.get("chat_template_kwargs", {}),
    )
    if text.count(content) != 1:
        raise ValueError(
            "chat template must preserve system content verbatim exactly once"
        )
    start = text.index(content)
    shifted = [dict(s, start=s["start"] + start, end=s["end"] + start) for s in spans]
    return text, (
        [{"block": "chat_header", "start": 0, "end": start}]
        + shifted
        + [{"block": "chat_footer", "start": start + len(content), "end": len(text)}]
    )


def render_request(spec, kept, tokenizer, query):
    content, _ = render(spec, kept)
    question = spec["query_format"].format(query=query)
    if spec.get("prompt_format", "plain") == "plain":
        return content + question
    text = tokenizer.apply_chat_template(
        [{"role": "system", "content": content}, {"role": "user", "content": question}],
        tokenize=False,
        add_generation_prompt=True,
        **spec.get("chat_template_kwargs", {}),
    )
    if not text.startswith(render_prefix(spec, kept, tokenizer)[0]):
        raise ValueError(
            "chat template changes system prefix when a user turn is appended"
        )
    return text


def tokenize(tokenizer, text, spans):
    """Tokenize the natural string; retain boundary-straddling tokens."""
    encoded = tokenizer(text, add_special_tokens=False, return_offsets_mapping=True)
    result = []
    counts = Counter()
    for pos, (tid, offset) in enumerate(
        zip(encoded["input_ids"], encoded["offset_mapping"], strict=True)
    ):
        start, end = offset
        span = next(
            (
                s
                for s in spans
                if end > start and s["start"] <= start and end <= s["end"]
            ),
            None,
        )
        block = span["block"] if span else "boundary"
        result.append(
            {
                "position": pos,
                "id": tid,
                "piece": tokenizer.decode([tid]),
                "block": block,
                "within_block": counts[block],
                "char_start": start,
                "char_end": end,
                "local_start": start - span["start"] if span else None,
                "local_end": end - span["start"] if span else None,
            }
        )
        counts[block] += 1
    if not result:
        raise ValueError("prefix must contain at least one token")
    return result


def align(source, subset):
    def key(t):
        return t["block"], t["local_start"], t["local_end"], t["id"]

    index = {}
    for token in source:
        if token["block"] != "boundary":
            index.setdefault(key(token), []).append(token["position"])
    counts = Counter()
    # Do not match offsets alone: token identity and block identity must agree.
    result = []
    for token in subset:
        candidates = index.get(key(token), []) if token["block"] != "boundary" else []
        occurrence = counts[key(token)]
        result.append(candidates[occurrence] if occurrence < len(candidates) else -1)
        counts[key(token)] += 1
    return result


def mask_features(mask, mapping):
    removed = mask["removed"]
    gaps = sum(i == 0 or removed[i - 1] + 1 != r for i, r in enumerate(removed))
    return {
        "removed_tools": len(removed),
        "kept_tools": len(mask["kept"]),
        "removed_runs": gaps,
        "boundary_recompute_tokens": mapping.count(-1),
        "reuse_eligible_tokens": sum(i >= 0 for i in mapping),
    }


def deletion_anchors(spec, mask, tokens):
    """First retained token after each actual removed-tool run, not BPE seams."""
    anchors = set()
    for removed in mask["removed"]:
        following = next((i for i in mask["kept"] if i > removed), None)
        targets = (
            [spec["tools"][following]["id"]]
            if following is not None
            else ["footer", "chat_footer"]
        )
        positions = [t["position"] for t in tokens if t["block"] in targets]
        if positions:
            anchors.add(min(positions))
    return sorted(anchors)
