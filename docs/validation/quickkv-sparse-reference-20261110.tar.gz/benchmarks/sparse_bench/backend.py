"""HF Qwen3 eager reference backend, deliberately separate from serving timing."""

import time

import numpy as np
import torch
from transformers import DynamicCache


class QwenBackend:
    def __init__(self, model, tokenizer):
        if model.config.model_type != "qwen3":
            raise ValueError(
                "reference backend currently supports unquantized Qwen3 only"
            )
        if getattr(model.config, "quantization_config", None):
            raise ValueError("quantized models require a separately validated backend")
        rope = getattr(model.config, "rope_parameters", None) or {}
        scaling = getattr(model.config, "rope_scaling", None) or {}
        if (
            rope.get("rope_type", "default") != "default"
            or scaling.get("rope_type", "default") != "default"
        ):
            raise ValueError("delta rotation is validated for default RoPE only")
        self.model, self.tokenizer = model.eval(), tokenizer
        model.requires_grad_(False)
        self.device = next(model.parameters()).device

    def tensor(self, ids):
        return torch.tensor([ids], dtype=torch.long, device=self.device)

    def synchronize(self):
        if self.device.type == "cuda":
            torch.cuda.synchronize(self.device)

    def timed(self, function):
        self.synchronize()
        start = time.perf_counter()
        value = function()
        self.synchronize()
        return value, (time.perf_counter() - start) * 1000

    @staticmethod
    def cache(kv):
        cache = DynamicCache()
        for i, (k, v) in enumerate(kv):
            cache.update(k.clone(), v.clone(), i)
        return cache

    @torch.inference_mode()
    def prefill(self, ids):
        cache = self.model.model(self.tensor(ids), use_cache=True).past_key_values
        return [
            (layer.keys.detach().clone(), layer.values.detach().clone())
            for layer in cache.layers
        ]

    @torch.inference_mode()
    def exact(self, source, ids, matched):
        """Native HF prefix continuation for the numerical execution baseline."""
        if matched == 0:
            return self.prefill(ids)
        if matched == len(ids):
            return [
                (k[:, :, :matched].clone(), v[:, :, :matched].clone())
                for k, v in source
            ]
        cache = self.cache(self.slice(source, matched))
        cache = self.model.model(
            self.tensor(ids[matched:]), past_key_values=cache, use_cache=True
        ).past_key_values
        return [
            (layer.keys.detach().clone(), layer.values.detach().clone())
            for layer in cache.layers
        ]

    @staticmethod
    def array(kv):
        return (
            torch.stack(
                [
                    torch.stack([k[0].transpose(0, 1), v[0].transpose(0, 1)])
                    for k, v in kv
                ]
            )
            .float()
            .cpu()
            .numpy()
        )

    @staticmethod
    def slice(kv, length):
        return [(k[:, :, :length], v[:, :, :length]) for k, v in kv]

    @torch.inference_mode()
    def rotate_keys(self, key, delta):
        delta = torch.as_tensor(delta, device=self.device)
        inv = self.model.model.rotary_emb.inv_freq.float()
        angles = delta.float()[:, None] * inv[None, :]
        angles = torch.cat((angles, angles), dim=-1)[None, None]
        first, second = key.float().chunk(2, dim=-1)
        return (
            key.float() * angles.cos()
            + torch.cat((-second, first), dim=-1) * angles.sin()
        ).to(key.dtype)

    @torch.inference_mode()
    def independent_prefill(self, ids, cuts):
        """Bake each canonical token block at local position zero, then normalize K.

        Input IDs are unchanged from natural superset tokenization. Stored keys
        are rotated to source positions so both storage bases use one splice path.
        """
        if cuts != sorted(set(cuts)) or cuts[0] != 0 or cuts[-1] != len(ids):
            raise ValueError("invalid independent block cuts")
        chunks = []
        for start, end in zip(cuts[:-1], cuts[1:], strict=True):
            piece = self.prefill(ids[start:end])
            delta = torch.full((end - start,), start, device=self.device)
            chunks.append([(self.rotate_keys(k, delta), v) for k, v in piece])
        return [
            (
                torch.cat([piece[i][0] for piece in chunks], dim=2),
                torch.cat([piece[i][1] for piece in chunks], dim=2),
            )
            for i in range(len(chunks[0]))
        ]

    @torch.inference_mode()
    def splice(self, source, mapping, rotate, skip_positions=(), skip_layers=0):
        if not 0 <= skip_layers <= len(source):
            raise ValueError("invalid skipped layer count")
        if skip_positions or skip_layers:
            # Gather only retained cache entries. Recomputed slots are zero until
            # their fresh K/V is written, so their source values are never read.
            skipped = set(skip_positions)
            if any(i < 0 or i >= len(mapping) for i in skipped):
                raise ValueError("invalid skipped cache position")
            loaded = [
                i for i, src in enumerate(mapping) if src >= 0 and i not in skipped
            ]
            pos = torch.tensor(loaded, device=self.device, dtype=torch.long)
            index = torch.tensor(
                [mapping[i] for i in loaded], device=self.device, dtype=torch.long
            )
            result = []
            for li, (key, value) in enumerate(source):
                shape = (key.shape[0], key.shape[1], len(mapping), key.shape[3])
                k, v = key.new_zeros(shape), value.new_zeros(shape)
                if li >= skip_layers and loaded:
                    fresh = key[:, :, index]
                    k[:, :, pos] = (
                        self.rotate_keys(fresh, pos - index) if rotate else fresh
                    )
                    v[:, :, pos] = value[:, :, index]
                result.append((k, v))
            return result
        valid = torch.tensor([i >= 0 for i in mapping], device=self.device)
        index = torch.tensor([max(0, i) for i in mapping], device=self.device)
        delta = torch.arange(len(mapping), device=self.device) - index
        result = []
        for k, v in source:
            k, v = k[:, :, index].clone(), v[:, :, index].clone()
            if rotate:
                k = self.rotate_keys(k, delta)
            k[:, :, ~valid] = 0
            v[:, :, ~valid] = 0
            result.append((k, v))
        return result

    @torch.inference_mode()
    def recompute(
        self,
        base,
        ids,
        positions,
        check_layer=None,
        candidates=None,
        budget=0,
        importance=None,
        importance_power=1,
        refresh_layers=None,
    ):
        """Selected queries attend to updated mixed KV, with explicit causal positions.

        For early-key selection, every token traverses layers before check_layer;
        fresh K is compared there, then a fixed mask is used for remaining layers.
        refresh_layers instead refreshes all tokens through that many layers,
        then continues only mandatory boundary queries without a key comparison.
        Boundary tokens are mandatory at all layers. No cold KV is accepted here.
        """
        from transformers.models.qwen3.modeling_qwen3 import apply_rotary_pos_emb

        edited = [(k.clone(), v.clone()) for k, v in base]
        mandatory = sorted(set(positions))
        if refresh_layers is not None:
            if check_layer is not None or not 1 <= refresh_layers <= len(edited):
                raise ValueError("invalid leading layer refresh")
            positions = list(range(len(ids)))
        if check_layer is not None:
            if not 0 < check_layer < len(edited):
                raise ValueError(
                    "check_layer must be strictly between 0 and number of layers"
                )
            positions = list(range(len(ids)))
        pos = torch.tensor(sorted(set(positions)), device=self.device, dtype=torch.long)
        if not len(pos):
            return edited, []
        hidden = self.model.model.embed_tokens(self.tensor(ids))[:, pos]
        selected = mandatory
        for li, layer in enumerate(self.model.model.layers):
            if li == refresh_layers:
                # Only boundary queries continue. Later valid K/V stays loaded.
                pos = torch.tensor(mandatory, device=self.device, dtype=torch.long)
                if not len(pos):
                    break
                hidden = hidden[:, pos]
            emb = self.model.model.rotary_emb(hidden, pos[None])
            if li == check_layer:
                attn = layer.self_attn
                norm = layer.input_layernorm(hidden)
                shape = (*norm.shape[:-1], -1, attn.head_dim)
                key = attn.k_norm(attn.k_proj(norm).view(shape)).transpose(1, 2)
                # apply_rotary_pos_emb does not mix heads, so K can be passed as Q too.
                _, key = apply_rotary_pos_emb(key, key, *emb)
                score = (key.float() - edited[li][0].float()).square().sum((0, 1, 3))
                scores = score.cpu().numpy()
                if importance is not None:
                    scale = float(np.mean(importance[candidates])) if candidates else 0
                    weights = (
                        importance / scale if scale > 0 else np.ones_like(importance)
                    )
                    scores = scores * (0.1 + weights) ** importance_power
                ranked = sorted(candidates, key=lambda i: (-float(scores[i]), i))
                selected = sorted(set(mandatory + ranked[:budget]))
                pos = torch.tensor(selected, device=self.device, dtype=torch.long)
                if not len(pos):
                    break
                hidden = hidden[:, pos]
                emb = self.model.model.rotary_emb(hidden, pos[None])
            causal = torch.zeros(
                (1, 1, len(pos), len(ids)), device=self.device, dtype=hidden.dtype
            )
            causal.masked_fill_(
                torch.arange(len(ids), device=self.device)[None] > pos[:, None],
                torch.finfo(hidden.dtype).min,
            )

            class ReplaceCache:
                def __init__(self, positions):
                    self.positions = positions

                def update(self, key, value, layer_idx, *args, **kwargs):
                    k, v = edited[layer_idx]
                    k[:, :, self.positions], v[:, :, self.positions] = key, value
                    return k, v

            hidden = layer(
                hidden,
                attention_mask=causal,
                position_ids=pos[None],
                past_key_values=ReplaceCache(pos),
                position_embeddings=emb,
            )
        return edited, selected

    @torch.inference_mode()
    def generate(self, prefix, suffix, max_tokens):
        cache = self.cache(prefix)
        logits = self.model(
            self.tensor(suffix), past_key_values=cache, use_cache=True
        ).logits[0, -1]
        self.synchronize()
        # Caller times the full function; TTFT is measured separately inside it.
        tokens = []
        eos = self.model.generation_config.eos_token_id
        eos = set(eos if isinstance(eos, list) else [eos])
        for _ in range(max_tokens):
            token = int(logits.argmax().item())
            tokens.append(token)
            if token in eos:
                break
            if len(tokens) < max_tokens:
                logits = self.model(
                    self.tensor([token]), past_key_values=cache, use_cache=True
                ).logits[0, -1]
        return {
            "tokens": tokens,
            "text": self.tokenizer.decode(tokens, skip_special_tokens=True),
            "finish": "eos" if tokens[-1] in eos else "length",
        }

    @torch.inference_mode()
    def teacher_logits(self, prefix, suffix, history):
        inputs = suffix + history[:-1]
        logits = self.model(
            self.tensor(inputs), past_key_values=self.cache(prefix), use_cache=True
        ).logits
        start = len(suffix) - 1
        return logits[0, start : start + len(history)].float().cpu().numpy()


def select_gap_chunks(length, anchors, chunk_size):
    """Fixed windows after each deletion run, clipped and merged in subset space."""
    if chunk_size < 1 or any(a < 0 or a >= length for a in anchors):
        raise ValueError("invalid deletion chunk")
    return sorted({i for a in anchors for i in range(a, min(a + chunk_size, length))})


def select_positions(method, base, reference, mapping, count, seed, gap_anchors=None):
    """Shared global candidate domain and stable tie-breaking for all policies."""
    candidates = [i for i, src in enumerate(mapping) if src >= 0]
    if not 0 <= count <= len(candidates):
        raise ValueError("budget exceeds eligible tokens")
    if method == "random":
        ranked = np.random.default_rng(seed).permutation(candidates).tolist()
    elif method == "gap":
        if gap_anchors is None:
            raise ValueError("gap selection requires explicit removed-tool anchors")
        distances = {
            i: min((i - a for a in gap_anchors if a <= i), default=float("inf"))
            for i in candidates
        }
        ranked = sorted(candidates, key=lambda i: (distances[i], i))
    elif method == "oracle_diff":
        scores = sum(
            (a.float() - b.float()).square().sum((0, 1, 3)).cpu().numpy()
            for pair, ref in zip(base, reference, strict=True)
            for a, b in zip(pair, ref, strict=True)
        )
        ranked = sorted(candidates, key=lambda i: (-float(scores[i]), i))
    else:
        raise ValueError(method)
    return sorted(ranked[:count])
