"""Sufficient statistics: aggregate squared energies before taking relative norms."""

import json
import re

import numpy as np


def kv_stats(arm, reference):
    """Inputs [layer, 2(K,V), token, head, dim]; outputs retain layer and token."""
    if arm.shape != reference.shape or arm.ndim != 5 or arm.shape[1] != 2:
        raise ValueError("expected matching [layer, 2, token, head, dim] arrays")
    if not np.isfinite(arm).all() or not np.isfinite(reference).all():
        raise ValueError("non-finite KV")
    a, b = arm.astype(np.float64), reference.astype(np.float64)
    diff = a - b
    error = np.square(diff).sum(axis=(-1, -2))
    energy = np.square(b).sum(axis=(-1, -2))
    return {
        "error_sq": error,
        "reference_sq": energy,
        "max_abs": np.abs(diff).max(axis=(-1, -2)),
        "dot": (a * b).sum(axis=(-1, -2)),
        "arm_sq": np.square(a).sum(axis=(-1, -2)),
        "head_error_sq": np.square(diff).sum(axis=-1),
        "head_reference_sq": np.square(b).sum(axis=-1),
    }


def relative(error, reference):
    """Undefined zero-reference ratios are null, never silently zero/epsilon-clamped."""
    error, reference = float(error), float(reference)
    return (error / reference) ** 0.5 if reference > 0 else None


def summarize(stats, indices=None):
    indices = list(range(stats["error_sq"].shape[-1])) if indices is None else indices
    result = {"tokens": len(indices)}
    for channel, kind in enumerate(("k", "v")):
        error = float(stats["error_sq"][:, channel, indices].sum())
        ref = float(stats["reference_sq"][:, channel, indices].sum())
        result[kind] = {
            "error_sq": error,
            "reference_sq": ref,
            "relative_l2": relative(error, ref),
            "max_abs": float(stats["max_abs"][:, channel, indices].max())
            if indices
            else None,
        }
    return result


def distributions(reference_logits, arm_logits):
    """Full-vocabulary, same-history distributions; logits [step, vocabulary]."""

    def probabilities(x):
        x = np.asarray(x, dtype=np.float64)
        x = x - x.max(axis=-1, keepdims=True)
        logp = x - np.log(np.exp(x).sum(axis=-1, keepdims=True))
        return logp, np.exp(logp)

    lr, pr = probabilities(reference_logits)
    la, pa = probabilities(arm_logits)
    if pr.shape != pa.shape or not np.isfinite(lr).all() or not np.isfinite(la).all():
        raise ValueError("invalid logit distributions")
    return {
        "tvd": (0.5 * np.abs(pr - pa).sum(axis=-1)).tolist(),
        "kl_cold_to_arm": (pr * (lr - la)).sum(axis=-1).tolist(),
        "argmax_agree": (pr.argmax(-1) == pa.argmax(-1)).tolist(),
    }


def token_preservation(reference, candidate):
    prefix = next(
        (
            i
            for i, (a, b) in enumerate(zip(reference, candidate, strict=False))
            if a != b
        ),
        min(len(reference), len(candidate)),
    )
    same = list(reference) == list(candidate)
    matches = sum(a == b for a, b in zip(reference, candidate, strict=False))
    return {
        "cold_generated_tokens": len(reference),
        "generated_tokens": len(candidate),
        "common_prefix_tokens": prefix,
        "common_prefix_fraction": prefix / len(reference)
        if reference
        else float(not candidate),
        "position_match_fraction": matches / max(len(reference), len(candidate))
        if reference or candidate
        else 1,
        "first_divergence": None if same else prefix,
        "prefix_survival": {
            str(h): prefix >= h if len(reference) >= h else None
            for h in (1, 4, 8, 16, 32, 48, 64, 96)
        },
    }


def judge(text, expected, allowed, output_format="label"):
    """Accept one exact tool label after stripping whitespace."""
    parsed = text.strip()
    if output_format == "tool_json":
        complete = False
        fenced = parsed.startswith("```")
        if fenced:
            parsed = re.sub(r"^```(?:json)?\s*", "", parsed)
            parsed = re.sub(r"\s*```\s*$", "", parsed)
        try:
            obj = json.loads(parsed)
            parsed = obj.get("tool") if isinstance(obj, dict) else None
            complete = isinstance(parsed, str) and parsed in allowed and not fenced
        except json.JSONDecodeError:
            match = re.match(r'^\s*\{\s*"tool"\s*:\s*("(?:[^"\\]|\\.)*")', parsed)
            try:
                parsed = json.loads(match[1]) if match else None
            except json.JSONDecodeError:
                parsed = None
        known = isinstance(parsed, str) and parsed in allowed
        return {
            "parsed": parsed if known else None,
            "format_valid": complete,
            "correct": known and parsed == expected,
        }
    if output_format == "tool_first_line":
        parsed = parsed.splitlines()[0].strip() if parsed else ""
    elif output_format != "label":
        raise ValueError("unknown response format")
    valid = parsed in allowed
    return {
        "parsed": parsed if valid else None,
        "format_valid": valid,
        "correct": valid and parsed == expected,
    }
