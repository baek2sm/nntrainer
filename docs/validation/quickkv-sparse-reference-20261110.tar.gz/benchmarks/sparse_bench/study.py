"""Compare frozen superset-gradient candidates using already verified report views."""

import argparse
import csv
import json
from pathlib import Path

import numpy as np

from .metrics import token_preservation


def read(path):
    return json.loads(Path(path).read_text())


def analyze(view):
    partial = {
        m
        for m, c in view["cases"].items()
        if 0 < len(c["mask"]["kept"]) < len(view["spec"]["tools"])
    }
    quality = [r for r in view["quality"] if r["mask"] in partial]
    cold = {
        (r["mask"], r["query"]): r["tokens"] for r in quality if r["method"] == "cold"
    }
    methods = sorted({r["method"] for r in quality} - {"cold", "exact"})
    reference = {
        (r["mask"], r["query"]): r
        for r in quality
        if r["method"] == "cacheblend_superset@0.15"
    }
    result = {}
    for method in methods:
        rows = [r for r in quality if r["method"] == method]
        keys = {(r["mask"], r["query"]) for r in rows}
        if keys != set(reference):
            raise ValueError(f"quality coverage mismatch for {method}")
        if len(keys) != len(rows):
            raise ValueError("duplicate quality records")
        preservation = [
            token_preservation(cold[r["mask"], r["query"]], r["tokens"]) for r in rows
        ]
        blocks = [
            r for r in view["blocks"] if r["mask"] in partial and r["method"] == method
        ]
        metrics = [
            r for r in view["rows"] if r["mask"] in partial and r["method"] == method
        ]
        by_mask = {}
        for row in rows:
            key = row["mask"], row["query"]
            delta = float(np.mean(row["teacher_forced"]["tvd"])) - float(
                np.mean(reference[key]["teacher_forced"]["tvd"])
            )
            by_mask.setdefault(row["mask"], []).append(delta)
        clusters = np.array([np.mean(values) for values in by_mask.values()])
        rng = np.random.default_rng(0)
        bootstrap = np.mean(
            clusters[rng.integers(len(clusters), size=(2000, len(clusters)))], axis=1
        )
        item = {
            "masks": len(partial),
            "queries": len(rows),
            "mean_teacher_tvd": float(
                np.mean([np.mean(r["teacher_forced"]["tvd"]) for r in rows])
            ),
            "mean_teacher_kl": float(
                np.mean([np.mean(r["teacher_forced"]["kl_cold_to_arm"]) for r in rows])
            ),
            "correct": sum(r["correct"] for r in rows),
            "cold_correct": sum(r["cold_correct"] for r in rows),
            "token_matches": sum(r["same_as_cold"] for r in rows),
            "mean_common_prefix_fraction": float(
                np.mean([p["common_prefix_fraction"] for p in preservation])
            ),
            "mean_common_prefix_tokens": float(
                np.mean([p["common_prefix_tokens"] for p in preservation])
            ),
            "mean_position_match_fraction": float(
                np.mean([p["position_match_fraction"] for p in preservation])
            ),
            "mean_teacher_argmax_agreement": float(
                np.mean([np.mean(r["teacher_forced"]["argmax_agree"]) for r in rows])
            ),
            "mean_cold_generated_tokens": float(
                np.mean([p["cold_generated_tokens"] for p in preservation])
            ),
            "prefix_survival": {
                str(h): {
                    "eligible": sum(
                        p["prefix_survival"][str(h)] is not None for p in preservation
                    ),
                    "preserved": sum(
                        p["prefix_survival"][str(h)] is True for p in preservation
                    ),
                }
                for h in (1, 4, 8, 16, 32, 48, 64, 96)
            },
            "cold_right_to_wrong": sum(
                r["cold_correct"] and not r["correct"] for r in rows
            ),
            "cold_wrong_to_right": sum(
                not r["cold_correct"] and r["correct"] for r in rows
            ),
            "construction_median_ms": float(
                np.median([r["construction_median_ms"] for r in metrics])
            ),
            "paired_tvd_delta_vs_cacheblend": float(np.mean(clusters)),
            "paired_tvd_delta_ci95_mask_bootstrap": np.percentile(
                bootstrap, [2.5, 97.5]
            ).tolist(),
        }
        for kind in ("k", "v"):
            error = sum(r[kind + "_error_sq"] for r in blocks)
            energy = sum(r[kind + "_reference_sq"] for r in blocks)
            item[kind + "_pooled_relative_l2"] = (
                (error / energy) ** 0.5 if energy else None
            )
        for present in (True, False):
            group = [r for r in rows if r["target_present"] == present]
            item["present" if present else "absent"] = {
                "correct": sum(r["correct"] for r in group),
                "queries": len(group),
            }
        result[method] = item
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--diagnostic-report", required=True)
    p.add_argument("--validation-report")
    p.add_argument("--out", required=True)
    args = p.parse_args()
    dev = read(Path(args.diagnostic_report) / "view.json")
    report = {"diagnostic": analyze(dev)}
    gradients = [m for m in report["diagnostic"] if m.startswith("grad_")]
    best = max(
        gradients,
        key=lambda m: (
            report["diagnostic"][m]["token_matches"]
            / report["diagnostic"][m]["queries"],
            report["diagnostic"][m]["mean_common_prefix_fraction"],
            -report["diagnostic"][m]["mean_teacher_tvd"],
        ),
    )
    report["best_gradient_on_diagnostic"] = best
    if args.validation_report:
        val = read(Path(args.validation_report) / "view.json")
        if val["summary"]["manifest_sha256"] != dev["summary"]["manifest_sha256"]:
            raise ValueError("manifest mismatch")
        if set(val["cases"]) & set(dev["cases"]):
            raise ValueError("validation masks overlap diagnostic masks")
        report["validation"] = analyze(val)
        report["validation_of_diagnostic_choice"] = report["validation"][best]
    report["scope"] = {
        "selection": (
            "superset-only offline gradients; no subset GT or response targets"
        ),
        "ranking_criterion": (
            "full token match, common-prefix fraction; "
            "teacher TVD as tie breaker, diagnostic only"
        ),
        "uncertainty": (
            "descriptive mask bootstrap conditional on fixed model/template/query sets"
        ),
        "latency": "HF CPU reference; one timed sample per case; not serving TTFT",
        "no_claim": (
            "distributional similarity alone does not establish "
            "token or task-accuracy improvement"
        ),
    }
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    (out / "findings.json").write_text(
        json.dumps(report, indent=2, allow_nan=False) + "\n"
    )
    fields = [
        "phase",
        "method",
        "masks",
        "queries",
        "k_pooled_relative_l2",
        "v_pooled_relative_l2",
        "mean_teacher_tvd",
        "mean_teacher_kl",
        "correct",
        "cold_correct",
        "token_matches",
        "mean_common_prefix_fraction",
        "mean_position_match_fraction",
        "mean_teacher_argmax_agreement",
        "construction_median_ms",
        "paired_tvd_delta_vs_cacheblend",
    ]
    with (out / "comparison.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for phase in ("diagnostic", "validation"):
            for method, item in report.get(phase, {}).items():
                writer.writerow(
                    {
                        "phase": phase,
                        "method": method,
                        **{k: item[k] for k in fields if k not in ("phase", "method")},
                    }
                )
    print("Best gradient on diagnostic:", best)
    for phase in ("diagnostic", "validation"):
        if phase in report:
            for method in ("rope", "gap@0.15", "cacheblend_superset@0.15", best):
                item = report[phase][method]
                print(
                    phase,
                    method,
                    "TVD",
                    item["mean_teacher_tvd"],
                    "correct",
                    f"{item['correct']}/{item['queries']}",
                    "matches",
                    item["token_matches"],
                )


if __name__ == "__main__":
    main()
