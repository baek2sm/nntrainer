"""Offline KV sensitivity from the superset alone; no subset/response GT inputs."""

import numpy as np
import torch

OBJECTIVES = ("all", "tools", "tail")
RULES = ("l2", "abs", "scaled")
GRADIENT_METHODS = tuple(f"grad_{o}_{r}" for o in OBJECTIVES for r in RULES) + (
    "grad_tools_scaled_affected",
    "grad_blend_soft",
    "grad_blend_strong",
)


def target_weights(tokens, objective, device):
    """Position i predicts token i+1. Equal tool-block weight avoids length bias."""
    labels = tokens[1:]
    weights = np.zeros(len(labels), dtype=np.float32)
    fixed = {"header", "footer", "chat_header", "chat_footer", "boundary"}
    if objective == "all":
        weights[:] = 1
    elif objective == "tail":
        weights[:] = [t["block"] in ("footer", "chat_footer") for t in labels]
    elif objective == "tools":
        blocks = sorted({t["block"] for t in labels} - fixed)
        for block in blocks:
            positions = [i for i, t in enumerate(labels) if t["block"] == block]
            weights[positions] = 1 / len(positions)
    else:
        raise ValueError(objective)
    if weights.sum() == 0:
        raise ValueError(f"no labels for gradient objective {objective}")
    return torch.as_tensor(weights / weights.sum(), device=device)


def prefix_loss(backend, ids, kv, weights):
    """Teacher-forced superset likelihood with external KV treated as variables."""
    pos = torch.arange(len(ids), device=backend.device)
    hidden = backend.model.model.embed_tokens(backend.tensor(ids))
    emb = backend.model.model.rotary_emb(hidden, pos[None])
    causal = torch.zeros(
        (1, 1, len(ids), len(ids)), device=backend.device, dtype=hidden.dtype
    )
    causal.masked_fill_(pos[None] > pos[:, None], torch.finfo(hidden.dtype).min)

    class ReadCache:
        def update(self, key, value, layer_idx, *args, **kwargs):
            return kv[layer_idx]

    for layer in backend.model.model.layers:
        hidden = layer(
            hidden,
            attention_mask=causal,
            position_ids=pos[None],
            past_key_values=ReadCache(),
            position_embeddings=emb,
        )
    hidden = backend.model.model.norm(hidden[:, :-1])
    logits = backend.model.lm_head(hidden).float()
    loss = torch.nn.functional.cross_entropy(
        logits.reshape(-1, logits.shape[-1]),
        backend.tensor(ids[1:]).reshape(-1),
        reduction="none",
    )
    return (loss * weights).sum()


def build_profiles(backend, ids, tokens, source):
    """Only the full superset and its KV are accepted; weights remain frozen."""
    if next(backend.model.parameters()).dtype != torch.float32:
        raise ValueError("gradient reference currently requires float32")
    profiles, diagnostics, objectives = {}, {}, {}
    for objective in OBJECTIVES:
        weights = target_weights(tokens, objective, backend.device)
        with torch.enable_grad():
            leaves = [
                (
                    k.detach().clone().requires_grad_(),
                    v.detach().clone().requires_grad_(),
                )
                for k, v in source
            ]
            loss = prefix_loss(backend, ids, leaves, weights)
            gradients = torch.autograd.grad(loss, [a for pair in leaves for a in pair])
        if not all(torch.isfinite(g).all() for g in gradients):
            raise RuntimeError("non-finite superset gradient")
        if not any(torch.count_nonzero(g) > 0 for g in gradients):
            raise RuntimeError("zero superset gradients")
        objectives[objective] = {
            "loss": float(loss.detach()),
            "target_tokens": int(torch.count_nonzero(weights)),
        }
        for rule in RULES:
            layers = []
            for li, pair in enumerate(source):
                channels = []
                for channel, value in enumerate(pair):
                    grad = gradients[li * 2 + channel].detach().float()
                    value = value.detach().float()
                    if rule == "l2":
                        score = grad.square().sum((0, 1, 3)).sqrt()
                    elif rule == "scaled":
                        # Headwise norm product is invariant to common RoPE rotation.
                        score = (
                            grad.square().sum(-1).sqrt() * value.square().sum(-1).sqrt()
                        ).sum((0, 1))
                    else:
                        # Canonical pre-RoPE basis for coordinatewise attribution.
                        if channel == 0:
                            delta = -torch.arange(len(ids), device=backend.device)
                            grad = backend.rotate_keys(grad, delta)
                            value = backend.rotate_keys(value, delta)
                        score = (grad * value).abs().sum((0, 1, 3))
                    channels.append(score.cpu().numpy())
                layers.append(channels)
            array = np.asarray(layers, dtype=np.float64)
            name = f"grad_{objective}_{rule}"
            diagnostics[name + "_layer_kv_token"] = array
            profiles[name] = array.sum(axis=(0, 1))
        del leaves, loss, gradients
    metadata = {
        "uses_subset_gt": False,
        "uses_queries": False,
        "point": "cold superset KV; frozen model",
        "objectives": objectives,
        "note": "prefix next-token sensitivity is a proxy, not response correctness",
    }
    return profiles, diagnostics, metadata


def select_profile(profile, mapping, count, affected_after=None):
    candidates = [i for i, source in enumerate(mapping) if source >= 0]
    if not 0 <= count <= len(candidates):
        raise ValueError("invalid gradient selection budget")
    ranked = sorted(
        candidates,
        key=lambda i: (
            affected_after is not None and i < affected_after,
            -float(profile[mapping[i]]),
            i,
        ),
    )
    return sorted(ranked[:count])
