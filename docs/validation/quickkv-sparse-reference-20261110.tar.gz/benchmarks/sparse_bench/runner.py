"""Execute a fixed manifest, fail closed on integrity failures, save raw statistics."""

import hashlib
import importlib.metadata
import json
import math
import os
import platform
import subprocess
import sys
from functools import partial
from pathlib import Path

import numpy as np
import torch

from .backend import QwenBackend, select_gap_chunks, select_positions
from .cases import (
    align,
    deletion_anchors,
    digest,
    mask_features,
    read_manifest,
    render_prefix,
    render_request,
    tokenize,
)
from .metrics import distributions, judge, kv_stats, summarize, token_preservation
from .saliency import GRADIENT_METHODS, build_profiles, select_profile

CHUNK_METHODS = {f"gap_chunk{size}": size for size in (16, 32, 64)}
LAYER_METHODS = {f"early_layers{count}": count for count in (1, 2, 4, 8)}
FIXED_METHODS = ("exact", "splice", "rope", *CHUNK_METHODS, *LAYER_METHODS)

METHODS = (
    (
        "exact",
        "splice",
        "rope",
        "random",
        "gap",
        "oracle_diff",
        "oracle_copy",
        "early_key",
        "cacheblend_superset",
        "cacheblend_independent",
    )
    + GRADIENT_METHODS
    + tuple(CHUNK_METHODS)
    + tuple(LAYER_METHODS)
)


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
    )
    temp.replace(path)


def file_sha256(path):
    checksum = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(chunk)
    return checksum.hexdigest()


def provenance(model, tokenizer):
    def git(*args):
        p = subprocess.run(["git", *args], capture_output=True, text=True, check=False)
        return p.stdout.strip() if p.returncode == 0 else None

    versions = {}
    for package in ("torch", "transformers", "numpy", "tokenizers", "matplotlib"):
        try:
            versions[package] = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            versions[package] = None
    sources = {
        p.name: file_sha256(p)
        for p in Path(__file__).parent.iterdir()
        if p.suffix in (".py", ".json", ".html")
    }
    return {
        "python": sys.version,
        "platform": platform.platform(),
        "packages": versions,
        "git_commit": git("rev-parse", "HEAD"),
        "git_status": git("status", "--short"),
        "tracked_diff_sha256": digest(git("diff", "HEAD")),
        "benchmark_sources": sources,
        "model_config": model.config.to_dict(),
        "model_commit": getattr(model.config, "_commit_hash", None),
        "generation_config": model.generation_config.to_dict(),
        "tokenizer_class": type(tokenizer).__name__,
        "tokenizer_sha256": digest(tokenizer.backend_tokenizer.to_str()),
        "special_tokens": tokenizer.special_tokens_map,
        "torch_threads": torch.get_num_threads(),
        "torch_float32_matmul_precision": torch.get_float32_matmul_precision(),
        "cuda_matmul_tf32": torch.backends.cuda.matmul.allow_tf32,
        "deterministic_algorithms": torch.are_deterministic_algorithms_enabled(),
        "cuda_runtime": torch.version.cuda,
        "device": str(next(model.parameters()).device),
        "gpu": torch.cuda.get_device_name()
        if next(model.parameters()).is_cuda
        else None,
        "environment": {
            k: os.environ[k]
            for k in (
                "HF_HUB_OFFLINE",
                "HF_HUB_DISABLE_XET",
                "CUBLAS_WORKSPACE_CONFIG",
                "CUDA_VISIBLE_DEVICES",
                "VLLM_BATCH_INVARIANT",
                "VLLM_ATTENTION_BACKEND",
            )
            if k in os.environ
        },
    }


def assert_close(backend, left, right, name, atol, rtol):
    maximum = max(
        float((a.float() - b.float()).abs().max())
        for pair, ref in zip(left, right, strict=True)
        for a, b in zip(pair, ref, strict=True)
    )
    passed = all(
        torch.allclose(a, b, atol=atol, rtol=rtol)
        for pair, ref in zip(left, right, strict=True)
        for a, b in zip(pair, ref, strict=True)
    )
    if not passed:
        raise RuntimeError(
            f"integrity gate failed: {name}; max_abs={maximum}, "
            f"atol={atol}, rtol={rtol}"
        )
    return {
        "name": name,
        "passed": True,
        "max_abs": maximum,
        "atol": atol,
        "rtol": rtol,
    }


def measure(backend, function, repeats):
    # A discarded warm-up uses the identical computation and shape.
    function()
    elapsed = []
    memory = []
    for _ in range(repeats):
        if backend.device.type == "cuda":
            baseline = torch.cuda.memory_allocated(backend.device)
            torch.cuda.reset_peak_memory_stats(backend.device)
        value, ms = backend.timed(function)
        elapsed.append(ms)
        if backend.device.type == "cuda":
            memory.append(
                {
                    "resident_before_bytes": baseline,
                    "peak_allocated_bytes": torch.cuda.max_memory_allocated(
                        backend.device
                    ),
                    "peak_reserved_bytes": torch.cuda.max_memory_reserved(
                        backend.device
                    ),
                }
            )
    return value, {
        "samples_ms": elapsed,
        "median_ms": float(np.median(elapsed)),
        "p95_ms": float(np.percentile(elapsed, 95)),
        "repeats": repeats,
        "warmups": 1,
        "cuda_memory_samples": memory,
        "memory_scope": (
            "process allocator with source/cold/prior query arms resident; "
            "not isolated serving peak"
        ),
    }


def evaluate_queries(backend, spec, mask, prefix_text, tokens, arms, args):
    kept = {spec["tools"][i]["id"] for i in mask["kept"]}
    queries = [q for q in spec["queries"] if args.include_absent or q["target"] in kept]
    if args.query_families:
        queries = [q for q in queries if q["family"] in args.query_families]
    if args.query_limit is not None:
        queries = queries[: args.query_limit]
    prefix_ids = [t["id"] for t in tokens]
    rows = []
    for query in queries:
        text = render_request(spec, mask["kept"], backend.tokenizer, query["text"])
        if not text.startswith(prefix_text):
            raise ValueError("request no longer contains the planned prefix")
        ids = backend.tokenizer(text, add_special_tokens=False).input_ids
        matched = next(
            (
                i
                for i, (a, b) in enumerate(zip(prefix_ids, ids, strict=False))
                if a != b
            ),
            min(len(prefix_ids), len(ids)),
        )
        matched = min(matched, len(ids) - 1)
        suffix = ids[matched:]
        expected = query["target"] if query["target"] in kept else spec["no_tool"]
        allowed = kept | {spec["no_tool"]}
        cold = backend.slice(arms["cold"], matched)
        reference = backend.generate(cold, suffix, args.max_tokens)
        if len(reference["tokens"]) < args.min_reference_tokens:
            raise RuntimeError(
                f"cold trace shorter than required minimum: {mask['id']}/{query['id']}"
            )
        repeated = backend.generate(cold, suffix, args.max_tokens)
        if reference["tokens"] != repeated["tokens"]:
            raise RuntimeError(
                f"cold generation determinism gate failed: {mask['id']}/{query['id']}"
            )
        cold_logits = backend.teacher_logits(cold, suffix, reference["tokens"])
        # True full-request cold inference validates the prefix/query token boundary.
        with torch.inference_mode():
            full_logits = (
                backend.model(backend.tensor(ids), use_cache=False)
                .logits[0, -1]
                .float()
                .cpu()
                .numpy()
            )
        cached_logits = cold_logits[0]
        if not np.allclose(
            full_logits, cached_logits, atol=args.logit_atol, rtol=args.rtol
        ):
            raise RuntimeError(
                f"full-request cold gate failed: {mask['id']}/{query['id']}"
            )
        for name, kv in arms.items():
            prefix = backend.slice(kv, matched)
            output = (
                reference
                if name == "cold"
                else backend.generate(prefix, suffix, args.max_tokens)
            )
            logits = (
                cold_logits
                if name == "cold"
                else backend.teacher_logits(prefix, suffix, reference["tokens"])
            )
            metrics = distributions(cold_logits, logits)
            row = {
                "mask": mask["id"],
                "split": mask["split"],
                "method": name,
                "query": query["id"],
                "query_family": query["family"],
                "expected": expected,
                "target_present": query["target"] in kept,
                "prefix_matched_tokens": matched,
                "suffix_tokens": len(suffix),
                **output,
                **judge(
                    output["text"],
                    expected,
                    allowed,
                    spec.get("output_format", "label"),
                ),
                **token_preservation(reference["tokens"], output["tokens"]),
                "same_as_cold": output["tokens"] == reference["tokens"],
                "first_divergence": next(
                    (
                        i
                        for i, (a, b) in enumerate(
                            zip(output["tokens"], reference["tokens"], strict=False)
                        )
                        if a != b
                    ),
                    min(len(output["tokens"]), len(reference["tokens"]))
                    if len(output["tokens"]) != len(reference["tokens"])
                    else None,
                ),
                "cold_generation_repeat_passed": True,
                "cold_correct": judge(
                    reference["text"],
                    expected,
                    allowed,
                    spec.get("output_format", "label"),
                )["correct"],
                "teacher_forced": metrics,
                "full_request_cold_gate_max_abs": float(
                    np.abs(full_logits - cached_logits).max()
                ),
            }
            rows.append(row)
    return rows


@torch.inference_mode()
def construct(
    backend,
    source,
    mapping,
    ids,
    mandatory,
    candidates,
    cold,
    selection_seed,
    check_layer,
    method,
    budget,
    independent=None,
    gap_anchors=None,
    profiles=None,
):
    if method == "cold":
        return cold, []
    if method in LAYER_METHODS:
        count = LAYER_METHODS[method]
        base = backend.splice(
            source, mapping, True, skip_positions=mandatory, skip_layers=count
        )
        return backend.recompute(base, ids, mandatory, refresh_layers=count)
    if method in CHUNK_METHODS:
        if gap_anchors is None:
            raise ValueError("chunk repair requires actual deletion anchors")
        selected = sorted(
            set(mandatory)
            | set(select_gap_chunks(len(ids), gap_anchors, CHUNK_METHODS[method]))
        )
        base = backend.splice(source, mapping, True, skip_positions=selected)
        return backend.recompute(base, ids, selected)
    if method == "cacheblend_independent" and independent is None:
        raise ValueError("independent cache was not prepared")
    storage = independent if method == "cacheblend_independent" else source
    base = backend.splice(storage, mapping, method != "splice")
    if method == "exact":
        start = next((i for i, src in enumerate(mapping) if src != i), len(ids))
        return backend.recompute(base, ids, list(range(start, len(ids))))
    if method in ("splice", "rope"):
        return backend.recompute(base, ids, mandatory)
    count = math.ceil(budget * len(candidates))
    if method.startswith("grad_"):
        if profiles is None:
            raise ValueError("offline superset profiles were not prepared")
        if method in ("grad_blend_soft", "grad_blend_strong"):
            profile = profiles["grad_tools_scaled"]
            importance = np.array([profile[src] if src >= 0 else 0 for src in mapping])
            return backend.recompute(
                base,
                ids,
                mandatory,
                check_layer,
                candidates,
                count,
                importance,
                0.5 if method == "grad_blend_soft" else 1,
            )
        affected = method.endswith("_affected")
        key = method.removesuffix("_affected")
        selected = select_profile(
            profiles[key],
            mapping,
            count,
            min(gap_anchors) if affected and gap_anchors else None,
        )
        return backend.recompute(base, ids, sorted(set(mandatory + selected)))
    if method in ("early_key", "cacheblend_superset", "cacheblend_independent"):
        return backend.recompute(base, ids, mandatory, check_layer, candidates, count)
    selected = select_positions(
        "oracle_diff" if method == "oracle_copy" else method,
        base,
        cold if method.startswith("oracle") else None,
        mapping,
        count,
        selection_seed,
        gap_anchors,
    )
    if method == "oracle_copy":
        # Repair boundary queries against the corrected context, not stale pre-copy KV.
        for pair, ref in zip(base, cold, strict=True):
            for a, b in zip(pair, ref, strict=True):
                a[:, :, selected] = b[:, :, selected]
        base, _ = backend.recompute(base, ids, mandatory)
        return base, sorted(set(mandatory + selected))
    return backend.recompute(base, ids, sorted(set(mandatory + selected)))


def execute(args, backend=None):
    manifest = read_manifest(args.manifest)
    if args.repeats < 1 or args.max_tokens < 1:
        raise ValueError("repeats and max_tokens must be positive")
    if args.limit is not None and args.limit < 1:
        raise ValueError("limit must be positive")
    if args.query_limit is not None and args.query_limit < 1:
        raise ValueError("query-limit must be positive")
    families = {q["family"] for q in manifest["spec"]["queries"]}
    if args.query_families and set(args.query_families) - families:
        raise ValueError("unknown query families")
    budgets = sorted(set(args.budgets))
    if not budgets or any(not 0 <= b <= 1 for b in budgets):
        raise ValueError("budgets must be fractions in [0, 1]")
    if len({f"{b:g}" for b in budgets}) != len(budgets):
        raise ValueError("budgets too close to distinguish in artifact names")
    unknown = set(args.methods) - set(METHODS)
    if unknown:
        raise ValueError(f"unknown methods: {unknown}")
    masks = manifest["masks"]
    if args.masks:
        requested = set(args.masks.split(","))
        if requested - {m["id"] for m in masks}:
            raise ValueError("unknown mask IDs")
        masks = [m for m in masks if m["id"] in requested]
    if args.split != "all":
        masks = [m for m in masks if m["split"] == args.split]
    if not 0 <= args.shard_index < args.shards:
        raise ValueError("invalid shard index/count")
    masks = [m for m in masks if m["bits"] % args.shards == args.shard_index]
    if args.limit is not None:
        masks = masks[: args.limit]
    if not masks:
        raise ValueError("no masks selected")
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    previous, completed = None, set()
    if any(out.iterdir()):
        if not args.resume:
            raise ValueError("output directory must be empty; use a new run directory")
        previous = json.loads((out / "run.json").read_text())
        if previous["manifest_sha256"] != manifest["sha256"]:
            raise ValueError("resume manifest mismatch")
        original = {k: v for k, v in previous["config"].items() if k != "resume"}
        current = {k: v for k, v in vars(args).items() if k != "resume"}
        if original != current:
            raise ValueError("resume configuration mismatch")
        for mask in masks:
            marker = out / "cases" / mask["id"] / "complete.json"
            if not marker.exists():
                continue
            record = json.loads(marker.read_text())
            for name, checksum in record["files"].items():
                if file_sha256(marker.parent / name) != checksum:
                    raise ValueError("resume case checksum mismatch")
            completed.add(mask["id"])
    write_json(out / "manifest.json", manifest)
    config = vars(args).copy()
    run = {
        "schema_version": 1,
        "manifest_sha256": manifest["sha256"],
        "config": config,
        "mask_ids": [m["id"] for m in masks],
        "status": "running",
        "execution": "HF eager diagnostic reference; NOT serving TTFT",
        "timing_scope": (
            "method construction, including selection and boundary repair; "
            "excludes model load, cold oracle preparation, stats, "
            "query evaluation and reporting"
        ),
        "oracle_methods": ["oracle_diff", "oracle_copy"],
        "aggregation": (
            "sum squared errors and reference energies, then sqrt ratio; "
            "each token and layer contributes by energy"
        ),
    }
    write_json(out / "run.json", run)
    if previous:
        run["resume_history"] = previous.get("resume_history", []) + [
            {
                "previous_status": previous["status"],
                "previous_error": previous.get("error"),
                "previous_provenance": previous.get("provenance"),
                "reused_completed_cases": sorted(completed),
            }
        ]
    try:
        torch.manual_seed(manifest["seed"])
        if args.threads < 1:
            raise ValueError("threads must be positive")
        torch.set_num_threads(args.threads)
        torch.use_deterministic_algorithms(True)
        if backend is None:
            from transformers import AutoModelForCausalLM, AutoTokenizer

            tokenizer = AutoTokenizer.from_pretrained(
                args.model, revision=args.revision, local_files_only=True, use_fast=True
            )
            model = AutoModelForCausalLM.from_pretrained(
                args.model,
                revision=args.revision,
                local_files_only=True,
                dtype=getattr(torch, args.dtype),
                attn_implementation="eager",
            ).to(args.device)
            backend = QwenBackend(model, tokenizer)
        if not backend.tokenizer.is_fast:
            raise ValueError("fast tokenizer with character offsets required")
        run["provenance"] = provenance(backend.model, backend.tokenizer)
        write_json(out / "run.json", run)
        spec = manifest["spec"]
        full_text, spans = render_prefix(
            spec, list(range(len(spec["tools"]))), backend.tokenizer
        )
        source_tokens = tokenize(backend.tokenizer, full_text, spans)
        full_ids = [t["id"] for t in source_tokens]
        source = backend.prefill(full_ids)
        profiles = None
        if any(m.startswith("grad_") for m in args.methods):
            (profiles, diagnostic, metadata), elapsed = backend.timed(
                partial(build_profiles, backend, full_ids, source_tokens, source)
            )
            profile_file = out / "superset_saliency.npz"
            if previous and profile_file.exists():
                with np.load(profile_file, allow_pickle=False) as original:
                    for key, value in (profiles | diagnostic).items():
                        if not np.array_equal(original[key], value):
                            raise ValueError("resume superset gradient profile changed")
            np.savez_compressed(profile_file, **profiles, **diagnostic)
            run["offline_gradient"] = metadata | {
                "elapsed_ms": elapsed,
                "profile_sha256": file_sha256(profile_file),
                "amortization": (
                    "once per superset; excluded from request construction timing"
                ),
            }
            write_json(out / "run.json", run)
        independent = None
        if "cacheblend_independent" in args.methods:
            # H (including chat opening), each tool, F (including chat closing).
            names = [t["id"] for t in spec["tools"]] + ["footer"]
            cuts = [0]
            for block in names:
                positions = [
                    t["position"] for t in source_tokens if t["block"] == block
                ]
                if positions and positions[0] > cuts[-1]:
                    cuts.append(positions[0])
            cuts.append(len(full_ids))
            independent = backend.independent_prefill(full_ids, cuts)
            run["independent_source_blocks"] = [
                {"start": a, "end": b, "token_ids_sha256": digest(full_ids[a:b])}
                for a, b in zip(cuts[:-1], cuts[1:], strict=True)
            ]
        run["gates"] = [
            assert_close(
                backend,
                source,
                backend.prefill(full_ids),
                "superset_repeat",
                args.atol,
                args.rtol,
            )
        ]
        all_source, _ = backend.recompute(source, full_ids, list(range(len(full_ids))))
        run["gates"].append(
            assert_close(
                backend,
                source,
                all_source,
                "superset_full_recompute",
                args.atol,
                args.rtol,
            )
        )
        write_json(out / "source_tokens.json", source_tokens)
        if args.save_kv != "none":
            np.savez_compressed(out / "source_kv.npz", kv=backend.array(source))
        for mask in masks:
            if mask["id"] in completed:
                print(f"[resume] verified {mask['id']}", flush=True)
                continue
            print(
                f"[mask] {mask['id']} kept={len(mask['kept'])} split={mask['split']}",
                flush=True,
            )
            path = out / "cases" / mask["id"]
            text, spans = render_prefix(spec, mask["kept"], backend.tokenizer)
            tokens = tokenize(backend.tokenizer, text, spans)
            ids = [t["id"] for t in tokens]
            mapping = align(source_tokens, tokens)
            gap_anchors = deletion_anchors(spec, mask, tokens)
            mandatory = [i for i, src in enumerate(mapping) if src < 0]
            candidates = [i for i, src in enumerate(mapping) if src >= 0]
            for t, src in zip(tokens, mapping, strict=True):
                t["source_position"] = src
                t["mandatory_recompute"] = src < 0
            features = mask_features(mask, mapping)
            features["removed_source_tokens"] = len(full_ids) - len(set(mapping) - {-1})
            (cold, cold_timing) = measure(
                backend, partial(backend.prefill, ids), args.repeats
            )
            gates = [
                assert_close(
                    backend,
                    cold,
                    backend.prefill(ids),
                    "subset_repeat",
                    args.atol,
                    args.rtol,
                )
            ]
            # Reconstruct header and footer as well as tool tokens.
            full_recompute, _ = backend.recompute(
                source
                if mapping == list(range(len(full_ids)))
                else backend.splice(source, mapping, True),
                ids,
                list(range(len(ids))),
            )
            gates.append(
                assert_close(
                    backend,
                    cold,
                    full_recompute,
                    "subset_full_recompute",
                    args.atol,
                    args.rtol,
                )
            )
            reference = backend.array(cold)
            if args.save_kv != "none":
                path.mkdir(parents=True, exist_ok=True)
                np.savez_compressed(path / "reference_kv.npz", kv=reference)
            common = next((i for i, src in enumerate(mapping) if src != i), len(ids))
            native_exact = backend.exact(source, ids, common)
            numerical_floor = summarize(
                kv_stats(backend.array(native_exact), reference)
            )
            write_json(
                path / "case.json",
                {
                    "mask": mask,
                    "features": features,
                    "text": text,
                    "tokens": tokens,
                    "gates": gates,
                    "deletion_anchors": gap_anchors,
                    "native_exact_vs_cold_numerical_floor": numerical_floor,
                },
            )
            arms = {"cold": cold}

            variants = [("cold", 0)]
            for method in dict.fromkeys(["exact", *args.methods]):
                variants += [
                    (method, b)
                    for b in (budgets if method not in FIXED_METHODS else [0])
                ]
            for method, budget in variants:
                name = (
                    method
                    if method == "cold" or method in FIXED_METHODS
                    else f"{method}@{budget:g}"
                )
                if method == "cold":
                    kv, selected, timing = cold, [], cold_timing
                else:
                    (kv, selected), timing = measure(
                        backend,
                        partial(
                            construct,
                            backend,
                            source,
                            mapping,
                            ids,
                            mandatory,
                            candidates,
                            cold,
                            int(digest([args.selection_seed, mask["id"]])[:8], 16),
                            args.check_layer,
                            method,
                            budget,
                            independent,
                            gap_anchors,
                            profiles,
                        ),
                        args.repeats,
                    )
                if method == "exact":
                    gates.append(
                        assert_close(
                            backend,
                            native_exact,
                            kv,
                            "exact_vs_native_continuation",
                            args.atol,
                            args.rtol,
                        )
                    )
                if method in LAYER_METHODS:
                    count = LAYER_METHODS[method]
                    gates.append(
                        assert_close(
                            backend,
                            kv[:count],
                            cold[:count],
                            f"{method}_fresh_layers_vs_cold",
                            args.atol,
                            args.rtol,
                        )
                    )
                stats = kv_stats(backend.array(kv), reference)
                blocks = {
                    block: summarize(
                        stats, [i for i, t in enumerate(tokens) if t["block"] == block]
                    )
                    for block in dict.fromkeys(t["block"] for t in tokens)
                }
                record = {
                    "method": name,
                    "policy": method,
                    "selector_variant": "actual_removed_tool_distance_v2"
                    if method == "gap"
                    else method,
                    "budget_fraction": budget,
                    "oracle": method.startswith("oracle"),
                    "features": features,
                    "selected_positions": selected,
                    "mandatory_positions": mandatory,
                    "selected_eligible_tokens": len(set(selected) - set(mandatory)),
                    "early_full_prefix_layers": LAYER_METHODS.get(
                        method, args.check_layer
                    )
                    if method in LAYER_METHODS
                    or method
                    in (
                        "early_key",
                        "cacheblend_superset",
                        "cacheblend_independent",
                        "grad_blend_soft",
                        "grad_blend_strong",
                    )
                    else 0,
                    "selection_k_projection_layer": args.check_layer
                    if method
                    in (
                        "early_key",
                        "cacheblend_superset",
                        "cacheblend_independent",
                        "grad_blend_soft",
                        "grad_blend_strong",
                    )
                    else None,
                    "storage_context": "independent_blocks"
                    if method == "cacheblend_independent"
                    else "superset_sequential",
                    "timing": timing,
                    "overall": summarize(stats),
                    "blocks": blocks,
                }
                if method in LAYER_METHODS:
                    count = LAYER_METHODS[method]
                    layer_bytes = [
                        k.shape[1] * k.shape[3] * k.element_size()
                        + v.shape[1] * v.shape[3] * v.element_size()
                        for k, v in source
                    ]
                    record.update(
                        {
                            "selector_variant": "leading_layers_full_subset_v1",
                            "recomputed_prefix_layers": count,
                            "recomputed_token_layers": count * len(ids)
                            + (len(source) - count) * len(mandatory),
                            "kv_loaded_token_layers": (len(source) - count)
                            * len(candidates),
                            "kv_read_bytes": sum(layer_bytes[count:]) * len(candidates),
                            "kv_read_avoided_bytes": sum(layer_bytes[:count])
                            * len(candidates),
                            "io_scope": "logical tensor reads; no storage I/O timing",
                            "late_boundary_repair": len(mandatory),
                        }
                    )
                if method in CHUNK_METHODS:
                    loaded = [i for i in candidates if i not in set(selected)]
                    per_token = sum(
                        (k.shape[1] * k.shape[3] * k.element_size())
                        + (v.shape[1] * v.shape[3] * v.element_size())
                        for k, v in source
                    )
                    ranges = []
                    for pos in selected:
                        if ranges and ranges[-1][1] == pos:
                            ranges[-1][1] = pos + 1
                        else:
                            ranges.append([pos, pos + 1])
                    record.update(
                        {
                            "selector_variant": "fixed_window_after_each_deletion_v1",
                            "chunk_tokens_per_gap": CHUNK_METHODS[method],
                            "recompute_ranges": ranges,
                            "kv_loaded_tokens": len(loaded),
                            "kv_read_bytes": len(loaded) * per_token,
                            "kv_read_avoided_bytes": (len(candidates) - len(loaded))
                            * per_token,
                            "io_scope": (
                                "logical resident tensor gathers; "
                                "no disk or transfer timing"
                            ),
                        }
                    )
                write_json(path / name / "metrics.json", record)
                if args.save_kv == "all" and method != "cold":
                    np.savez_compressed(path / name / "kv.npz", kv=backend.array(kv))
                if args.token_level:
                    (path / name).mkdir(parents=True, exist_ok=True)
                    np.savez_compressed(
                        path / name / "stats.npz",
                        **{
                            k: v
                            for k, v in stats.items()
                            if args.heads or not k.startswith("head_")
                        },
                    )
                if not args.kv_only:
                    arms[name] = kv
            write_json(path / "gates.json", gates)
            if not args.kv_only:
                # Query results are written only after the case's integrity gates pass.
                write_json(
                    path / "quality.json",
                    evaluate_queries(backend, spec, mask, text, tokens, arms, args),
                )
            write_json(
                path / "complete.json",
                {
                    "mask": mask["id"],
                    "manifest_sha256": manifest["sha256"],
                    "files": {
                        str(p.relative_to(path)): file_sha256(p)
                        for p in sorted(path.rglob("*"))
                        if p.is_file()
                    },
                },
            )
        run["status"] = "complete"
    except Exception as exc:
        run["status"], run["error"] = "failed", f"{type(exc).__name__}: {exc}"
        raise
    finally:
        write_json(out / "run.json", run)
    return out
